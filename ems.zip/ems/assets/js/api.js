// API Interface for EMS

// Base API configuration
const API = {
    // Base API URL (empty string means relative to current domain)
    baseUrl: '',
    
    // Default headers for API requests
    defaultHeaders: {
        'Content-Type': 'application/json'
    },
    
    // Helper method for fetch requests
    async request(endpoint, method = 'GET', data = null) {
        const url = this.baseUrl + endpoint;
        const options = {
            method,
            headers: this.defaultHeaders,
            credentials: 'include' // Send cookies for authentication
        };
        
        // Add body data for non-GET requests
        if (data && method !== 'GET') {
            options.body = JSON.stringify(data);
        }
        
        try {
            const response = await fetch(url, options);
            
            // Parse JSON response
            const responseData = await response.json();
            
            // Handle API errors
            if (!response.ok) {
                throw new Error(responseData.error || `HTTP error! Status: ${response.status}`);
            }
            
            return responseData;
        } catch (error) {
            // Log error and rethrow
            console.error(`API ${method} request to ${endpoint} failed:`, error);
            throw error;
        }
    },
    
    // Authentication endpoints
    auth: {
        login(username, password) {
            return API.request('/api/login.php', 'POST', { username, password });
        },
        
        register(username, email, password, role = 'attendee') {
            return API.request('/api/register.php', 'POST', { 
                username, 
                email, 
                password, 
                role 
            });
        },
        
        logout() {
            return API.request('/api/logout.php', 'POST');
        },
        
        checkStatus() {
            return API.request('/api/auth-status.php');
        }
    },
    
    // Events endpoints
    events: {
        getAll(limit = 20, offset = 0) {
            return API.request(`/api/events.php?limit=${limit}&offset=${offset}`);
        },
        
        getById(eventId) {
            return API.request(`/api/events.php?event_id=${eventId}`);
        },
        
        create(eventData) {
            return API.request('/api/events.php', 'POST', eventData);
        },
        
        update(eventId, eventData) {
            return API.request('/api/events.php', 'PUT', {
                event_id: eventId,
                ...eventData
            });
        },
        
        delete(eventId) {
            return API.request(`/api/events.php?event_id=${eventId}`, 'DELETE');
        }
    },
    
    // Tickets endpoints
    tickets: {
        getForEvent(eventId) {
            return API.request(`/api/tickets.php?event_id=${eventId}`);
        },
        
        create(ticketData) {
            return API.request('/api/tickets.php', 'POST', ticketData);
        }
    },
    
    // Bookings endpoints
    bookings: {
        getUserBookings() {
            return API.request('/api/bookings.php');
        },
        
        create(ticketId, quantity) {
            return API.request('/api/bookings.php', 'POST', {
                ticket_id: ticketId,
                quantity
            });
        }
    },
    
    // Check-in endpoints
    checkin: {
        processQrCode(qrCode) {
            return API.request('/api/checkin.php', 'POST', { qr_code: qrCode });
        }
    },
    
    // Feedback endpoints
    feedback: {
        getForEvent(eventId) {
            return API.request(`/api/feedback.php?event_id=${eventId}`);
        },
        
        submit(eventId, rating, comments = '') {
            return API.request('/api/feedback.php', 'POST', {
                event_id: eventId,
                rating,
                comments
            });
        }
    },
    
    // Reports endpoints
    reports: {
        getEventReport(eventId) {
            return API.request(`/api/reports.php?event_id=${eventId}`);
        }
    },
    
    // Notifications endpoints
    notifications: {
        getUserNotifications(limit = 10) {
            return API.request(`/api/notifications.php?limit=${limit}`);
        },
        
        markAsRead(notificationId) {
            return API.request('/api/notifications.php', 'POST', {
                notification_id: notificationId
            });
        }
    },
    
    // Tasks endpoints
    tasks: {
        getForEvent(eventId) {
            return API.request(`/api/tasks.php?event_id=${eventId}`);
        },
        
        create(taskData) {
            return API.request('/api/tasks.php', 'POST', taskData);
        },
        
        updateStatus(taskId, status) {
            return API.request('/api/tasks.php', 'PUT', {
                task_id: taskId,
                status
            });
        }
    }
};

// Export API for use in other scripts
window.EmsAPI = API;