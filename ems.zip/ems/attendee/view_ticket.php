<?php
session_start();
require_once '../config/database.php';
require_once '../includes/auth_functions.php';

// Check if user is logged in
if (!isUserLoggedIn()) {
    header("Location: ../login.php");
    exit();
}

// Check if ticket ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: my_tickets.php");
    exit();
}

$ticket_id = intval($_GET['id']);
$user_id = $_SESSION['user_id'];

// Get ticket details (only if it belongs to the current user or user is an organizer/admin)
$stmt = $conn->prepare("
    SELECT t.*, e.title, e.start_date, e.end_date, e.location, e.created_by
    FROM tickets t
    JOIN events e ON t.event_id = e.event_id
    WHERE t.ticket_id = ? AND (t.user_id = ? OR ? IN (SELECT user_id FROM users WHERE role IN ('organizer', 'admin')))
");
$stmt->bind_param("iii", $ticket_id, $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    $_SESSION['error_message'] = "Ticket not found or you don't have permission to view it.";
    header("Location: my_tickets.php");
    exit();
}

$ticket = $result->fetch_assoc();

// Get user info
$stmt = $conn->prepare("SELECT username, email FROM users WHERE user_id = ?");
$stmt->bind_param("i", $ticket['user_id']);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Get seat information if available
$seat = null;
$stmt = $conn->prepare("
    SELECT s.*
    FROM seating s
    JOIN ticket_seats ts ON s.seating_id = ts.seating_id
    WHERE ts.ticket_id = ?
");
$stmt->bind_param("i", $ticket_id);
$stmt->execute();
$seat_result = $stmt->get_result();
if ($seat_result->num_rows > 0) {
    $seat = $seat_result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket #<?php echo $ticket_id; ?> - EMS</title>
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="stylesheet" href="../css/print.css" media="print">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container">
        <div class="ticket-container">
            <div class="ticket">
                <div class="ticket-header">
                    <h1><?php echo htmlspecialchars($ticket['title']); ?></h1>
                    <div class="ticket-id">Ticket #<?php echo $ticket['ticket_id']; ?></div>
                </div>
                
                <div class="ticket-details">
                    <div class="ticket-info">
                        <div class="info-group">
                            <h3>Event Details</h3>
                            <p><strong>Date:</strong> <?php echo date('M d, Y', strtotime($ticket['start_date'])); ?></p>
                            <p><strong>Time:</strong> <?php echo date('h:i A', strtotime($ticket['start_date'])); ?> - <?php echo date('h:i A', strtotime($ticket['end_date'])); ?></p>
                            <p><strong>Location:</strong> <?php echo htmlspecialchars($ticket['location']); ?></p>
                        </div>
                        
                        <div class="info-group">
                            <h3>Ticket Information</h3>
                            <p><strong>Type:</strong> <?php echo ucfirst($ticket['ticket_type']); ?></p>
                            <p><strong>Price:</strong> $<?php echo number_format($ticket['price'], 2); ?></p>
                            <?php if ($seat): ?>
                                <p><strong>Seat:</strong> Section <?php echo $seat['section']; ?>, Row <?php echo $seat['row']; ?>, Seat <?php echo $seat['seat_number']; ?></p>
                            <?php endif; ?>
                            <p><strong>Status:</strong> <span class="ticket-status <?php echo $ticket['status']; ?>"><?php echo ucfirst($ticket['status']); ?></span></p>
                        </div>
                        
                        <div class="info-group">
                            <h3>Purchased By</h3>
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
                            <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                            <p><strong>Purchase Date:</strong> <?php echo date('M d, Y h:i A', strtotime($ticket['purchase_date'])); ?></p>
                        </div>
                    </div>
                    
                    <div class="qr-container">
                        <h3>Entry QR Code</h3>
                        <div class="qr-code">
                            <img src="../uploads/qrcodes/<?php echo htmlspecialchars($ticket['qr_code']); ?>" alt="Entry QR Code">
                        </div>
                        <div class="qr-instructions">
                            <p>Please present this QR code at the event entrance for scanning.</p>
                        </div>
                    </div>
                </div>
                
                <div class="ticket-actions">
                    <button onclick="window.print()" class="button">Print Ticket</button>
                    <a href="download_ticket.php?id=<?php echo $ticket['ticket_id']; ?>" class="button">Download PDF</a>
                    <?php if ($ticket['status'] !== 'checked_in' && $ticket['start_date'] > date('Y-m-d H:i:s')): ?>
                        <a href="cancel_ticket.php?id=<?php echo $ticket['ticket_id']; ?>" class="button button-danger" onclick="return confirm('Are you sure you want to cancel this ticket?');">Cancel Ticket</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>
    <script src="../js/offline.js"></script>
</body>
</html>