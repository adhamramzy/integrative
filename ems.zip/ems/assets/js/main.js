// Main JavaScript for EMS application

document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    checkAuthStatus();
    
    // Set up navigation
    setupNavigation();
    
    // Check online/offline status
    handleNetworkStatus();
    
    // Initialize any page-specific functionality
    initCurrentPage();
});

// Function to check if user is logged in
function checkAuthStatus() {
    // Skip auth check for login and register pages
    if (window.location.pathname.includes('login.html') || 
        window.location.pathname.includes('register.html')) {
        return;
    }
    
    // Check session status
    fetch('/api/auth-status.php', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        if (!data.authenticated) {
            // Redirect to login if not authenticated
            window.location.href = 'login.html';
        } else {
            // Update UI with user info if needed
            if (document.getElementById('user-name')) {
                document.getElementById('user-name').textContent = data.username;
            }
            
            // Handle role-specific elements
            handleRoleSpecificElements(data.role);
        }
    })
    .catch(error => {
        console.error('Auth check error:', error);
    });
}

// Function to handle navigation
function setupNavigation() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            if (this.getAttribute('data-page')) {
                e.preventDefault();
                const targetPage = this.getAttribute('data-page');
                
                // Hide all pages
                document.querySelectorAll('.page').forEach(page => {
                    page.style.display = 'none';
                });
                
                // Show target page
                const targetElement = document.getElementById(`${targetPage}-page`);
                if (targetElement) {
                    targetElement.style.display = 'block';
                }
            }
        });
    });
    
    // Handle logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            fetch('/api/logout.php', {
                method: 'POST',
                credentials: 'include'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.href = 'login.html';
                }
            })
            .catch(error => {
                console.error('Logout error:', error);
            });
        });
    }
}

// Function to handle role-specific UI elements
function handleRoleSpecificElements(role) {
    const adminElements = document.querySelectorAll('.admin-only');
    const organizerElements = document.querySelectorAll('.organizer-only');
    const attendeeElements = document.querySelectorAll('.attendee-only');
    
    // Hide all role-specific elements first
    adminElements.forEach(el => el.style.display = 'none');
    organizerElements.forEach(el => el.style.display = 'none');
    attendeeElements.forEach(el => el.style.display = 'none');
    
    // Show elements based on user role
    if (role === 'admin') {
        adminElements.forEach(el => el.style.display = '');
        organizerElements.forEach(el => el.style.display = '');
    } else if (role === 'organizer') {
        organizerElements.forEach(el => el.style.display = '');
    } else if (role === 'attendee') {
        attendeeElements.forEach(el => el.style.display = '');
    }
}

// Function to check network status
function handleNetworkStatus() {
    const updateStatus = () => {
        const isOnline = navigator.onLine;
        
        // Update UI based on network status
        const networkStatus = document.getElementById('network-status');
        if (networkStatus) {
            networkStatus.textContent = isOnline ? 'Online' : 'Offline';
            networkStatus.style.color = isOnline ? '#3c763d' : '#a94442';
        }
        
        // Show/hide offline banner
        const offlineBanner = document.getElementById('offline-banner');
        if (offlineBanner) {
            offlineBanner.style.display = isOnline ? 'none' : 'block';
        }
        
        return isOnline;
    };
    
    // Initial check
    updateStatus();
    
    // Listen for online/offline events
    window.addEventListener('online', updateStatus);
    window.addEventListener('offline', updateStatus);
}

// Function to initialize page-specific functionality
function initCurrentPage() {
    // Dashboard page
    if (document.getElementById('dashboard-page') && 
        window.getComputedStyle(document.getElementById('dashboard-page')).display !== 'none') {
        initDashboard();
    }
    
    // Events page
    if (document.getElementById('events-page') && 
        window.getComputedStyle(document.getElementById('events-page')).display !== 'none') {
        initEvents();
    }
    
    // Tickets page
    if (document.getElementById('tickets-page') && 
        window.getComputedStyle(document.getElementById('tickets-page')).display !== 'none') {
        initTickets();
    }
}

// Dashboard initialization
function initDashboard() {
    // Load upcoming events
    fetch('/api/events.php?limit=5', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.events) {
            const eventsList = document.getElementById('upcoming-events-list');
            if (eventsList) {
                eventsList.innerHTML = '';
                
                if (data.events.length === 0) {
                    eventsList.innerHTML = '<li>No upcoming events</li>';
                } else {
                    data.events.forEach(event => {
                        const eventDate = new Date(event.start_datetime);
                        const formattedDate = eventDate.toLocaleDateString('en-US', { 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                        });
                        
                        const li = document.createElement('li');
                        li.innerHTML = `${event.title} - ${formattedDate}`;
                        eventsList.appendChild(li);
                    });
                }
            }
        }
    })
    .catch(error => {
        console.error('Error loading events:', error);
    });
    
    // Load notifications
    fetch('/api/notifications.php', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.notifications) {
            const activityList = document.getElementById('recent-activity');
            if (activityList) {
                activityList.innerHTML = '';
                
                if (data.notifications.length === 0) {
                    activityList.innerHTML = '<li>No recent activity</li>';
                } else {
                    data.notifications.forEach(notification => {
                        const li = document.createElement('li');
                        li.innerHTML = notification.message;
                        activityList.appendChild(li);
                    });
                }
            }
        }
    })
    .catch(error => {
        console.error('Error loading notifications:', error);
    });
}

// Events page initialization
function initEvents() {
    // Load events
    fetch('/api/events.php', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.events) {
            const eventListing = document.getElementById('event-listing');
            if (eventListing) {
                eventListing.innerHTML = '';
                
                if (data.events.length === 0) {
                    eventListing.innerHTML = '<p>No events found</p>';
                } else {
                    data.events.forEach(event => {
                        const eventDate = new Date(event.start_datetime);
                        const formattedDate = eventDate.toLocaleDateString('en-US', { 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                        });
                        
                        const eventCard = document.createElement('div');
                        eventCard.className = 'event-card';
                        eventCard.innerHTML = `
                            <div class="event-image">Event Image</div>
                            <div class="event-details">
                                <h3 class="event-title">${event.title}</h3>
                                <p class="event-info">Date: ${formattedDate}</p>
                                <p class="event-info">Location: ${event.location}</p>
                            </div>
                            <div class="event-action">
                                <button class="btn" data-event-id="${event.event_id}">Manage</button>
                            </div>
                        `;
                        
                        eventListing.appendChild(eventCard);
                    });
                    
                    // Add event listeners to manage buttons
                    document.querySelectorAll('.event-action .btn').forEach(btn => {
                        btn.addEventListener('click', function() {
                            const eventId = this.getAttribute('data-event-id');
                            window.location.href = `event-details.html?id=${eventId}`;
                        });
                    });
                }
            }
        }
    })
    .catch(error => {
        console.error('Error loading events:', error);
    });
    
    // Event form submission
    const eventForm = document.getElementById('event-form');
    if (eventForm) {
        eventForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const eventData = {
                title: document.getElementById('event-title').value,
                description: document.getElementById('event-description').value,
                location: document.getElementById('event-location').value,
                start_datetime: document.getElementById('event-start').value,
                end_datetime: document.getElementById('event-end').value,
                max_capacity: document.getElementById('event-capacity').value
            };
            
            fetch('/api/events.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(eventData),
                credentials: 'include'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Event created successfully!');
                    
                    // Reset form and return to events page
                    eventForm.reset();
                    document.getElementById('create-event-page').style.display = 'none';
                    document.getElementById('events-page').style.display = 'block';
                    
                    // Reload events list
                    initEvents();
                } else {
                    alert('Error: ' + (data.error || 'Failed to create event'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred. Please try again later.');
            });
        });
    }
}

// Tickets page initialization
function initTickets() {
    // Load user's bookings/tickets
    fetch('/api/bookings.php', {
        method: 'GET',
        credentials: 'include'
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.bookings) {
            const ticketsContainer = document.getElementById('tickets-container');
            if (ticketsContainer) {
                ticketsContainer.innerHTML = '';
                
                if (data.bookings.length === 0) {
                    ticketsContainer.innerHTML = '<p>You have no tickets</p>';
                } else {
                    data.bookings.forEach(booking => {
                        const eventDate = new Date(booking.start_datetime);
                        const formattedDate = eventDate.toLocaleDateString('en-US', { 
                            year: 'numeric', 
                            month: 'long', 
                            day: 'numeric' 
                        });
                        
                        const card = document.createElement('div');
                        card.className = 'card';
                        card.innerHTML = `
                            <div class="card-header">${booking.event_title}</div>
                            <div class="card-content">
                                <div style="text-align: center; margin: 20px 0;">
                                    <img src="https://chart.googleapis.com/chart?chs=150x150&cht=qr&chl=${booking.qr_code}" alt="QR Code" style="max-width: 150px;">
                                </div>
                                <p><strong>Date:</strong> ${formattedDate}</p>
                                <p><strong>Location:</strong> ${booking.location}</p>
                                <p><strong>Ticket Type:</strong> ${booking.ticket_type}</p>
                                <p><strong>Quantity:</strong> ${booking.quantity}</p>
                                <p><strong>Ticket ID:</strong> ${booking.booking_id}</p>
                            </div>
                        `;
                        
                        ticketsContainer.appendChild(card);
                    });
                }
            }
        }
    })
    .catch(error => {
        console.error('Error loading tickets:', error);
    });
}