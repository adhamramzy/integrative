<?php
/**
 * Check-in API Endpoint
 * 
 * Handles event check-in operations
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    jsonResponse(['error' => 'Authentication required']);
}

// Get current user
$user = getCurrentUser();
$db = getDbConnection();

// Only organizers and admins can check in attendees
if ($user['role'] !== 'organizer' && $user['role'] !== 'admin') {
    http_response_code(403);
    jsonResponse(['error' => 'Forbidden. Only organizers and admins can check in attendees']);
}

// POST request to validate QR code and process check-in
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate QR code
    if (!isset($data['qr_code'])) {
        http_response_code(400);
        jsonResponse(['error' => 'QR code required']);
    }
    
    $qrCode = sanitizeInput($data['qr_code']);
    
    try {
        // Begin transaction
        $db->beginTransaction();
        
        // Get booking information
        $stmt = $db->prepare("
            SELECT b.*, t.ticket_type, e.title as event_title, e.event_id, e.organizer_id
            FROM bookings b
            JOIN tickets t ON b.ticket_id = t.ticket_id
            JOIN events e ON t.event_id = e.event_id
            WHERE b.qr_code = ?
            FOR UPDATE
        ");
        $stmt->execute([$qrCode]);
        $booking = $stmt->fetch();
        
        if (!$booking) {
            $db->rollBack();
            http_response_code(404);
            jsonResponse(['error' => 'Invalid QR code. Booking not found']);
        }
        
        // Check if the user has permission for this event
        if ($booking['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
            $db->rollBack();
            http_response_code(403);
            jsonResponse(['error' => 'You do not have permission to check in attendees for this event']);
        }
        
        // Check if payment is completed
        if ($booking['payment_status'] !== 'completed') {
            $db->rollBack();
            jsonResponse(['error' => 'Booking payment is not completed. Status: ' . $booking['payment_status']]);
        }
        
        // Check if booking is already checked in
        $stmt = $db->prepare("SELECT * FROM check_ins WHERE booking_id = ?");
        $stmt->execute([$booking['booking_id']]);
        
        if ($stmt->rowCount() > 0) {
            $checkIn = $stmt->fetch();
            $checkInTime = new DateTime($checkIn['check_in_time']);
            $formattedTime = $checkInTime->format('Y-m-d H:i:s');
            
            $db->rollBack();
            jsonResponse(['error' => "Already checked in at $formattedTime"]);
        }
        
        // Process check-in
        $stmt = $db->prepare("
            INSERT INTO check_ins (booking_id, checked_in_by)
            VALUES (?, ?)
        ");
        $result = $stmt->execute([$booking['booking_id'], $user['user_id']]);
        
        if (!$result) {
            $db->rollBack();
            throw new Exception('Failed to record check-in');
        }
        
        // Create notification for the booking owner
        $stmt = $db->prepare("
            INSERT INTO notifications (user_id, event_id, message)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([
            $booking['user_id'],
            $booking['event_id'],
            "You have been checked in to {$booking['event_title']}."
        ]);
        
        // Commit the transaction
        $db->commit();
        
        // Log activity
        logActivity('check_in', "Checked in booking ID: {$booking['booking_id']} for event: {$booking['event_title']}", $user['user_id']);
        
        // Return success with booking details
        jsonResponse([
            'success' => true,
            'booking' => [
                'booking_id' => $booking['booking_id'],
                'event_title' => $booking['event_title'],
                'ticket_type' => $booking['ticket_type'],
                'quantity' => $booking['quantity']
            ],
            'message' => 'Check-in processed successfully'
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        
        http_response_code(500);
        jsonResponse(['error' => 'Failed to process check-in: ' . $e->getMessage()]);
    }
}

// GET request to get check-in stats for an event
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Validate event ID
    if (!isset($_GET['event_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Event ID required']);
    }
    
    $eventId = (int)$_GET['event_id'];
    
    // Check if event exists and user has permission
    $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event) {
        http_response_code(404);
        jsonResponse(['error' => 'Event not found']);
    }
    
    // Check if user has permission
    if ($event['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
        http_response_code(403);
        jsonResponse(['error' => 'You do not have permission to view check-in data for this event']);
    }
    
    // Get check-in statistics
    $stmt = $db->prepare("
        SELECT 
            COUNT(DISTINCT b.booking_id) as total_bookings,
            SUM(b.quantity) as total_tickets,
            COUNT(DISTINCT c.check_in_id) as total_checked_in,
            (COUNT(DISTINCT c.check_in_id) * 100.0 / COUNT(DISTINCT b.booking_id)) as check_in_percentage
        FROM tickets t
        LEFT JOIN bookings b ON t.ticket_id = b.ticket_id
        LEFT JOIN check_ins c ON b.booking_id = c.booking_id
        WHERE t.event_id = ? AND b.payment_status = 'completed'
    ");
    $stmt->execute([$eventId]);
    $stats = $stmt->fetch();
    
    // Get recent check-ins
    $stmt = $db->prepare("
        SELECT 
            c.check_in_id, 
            c.check_in_time, 
            u.username as attendee,
            t.ticket_type,
            b.quantity,
            cu.username as checked_in_by
        FROM check_ins c
        JOIN bookings b ON c.booking_id = b.booking_id
        JOIN users u ON b.user_id = u.user_id
        JOIN users cu ON c.checked_in_by = cu.user_id
        JOIN tickets t ON b.ticket_id = t.ticket_id
        WHERE t.event_id = ?
        ORDER BY c.check_in_time DESC
        LIMIT 10
    ");
    $stmt->execute([$eventId]);
    $recentCheckins = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'stats' => $stats,
        'recent_checkins' => $recentCheckins
    ]);
}

// If we get here, it's an unsupported method
http_response_code(405);
jsonResponse(['error' => 'Method not allowed']);