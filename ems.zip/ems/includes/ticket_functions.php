<?php
/**
 * Ticket management functions
 */

/**
 * Create a new ticket
 *
 * @param array $ticket_data Ticket data (event_id, user_id, ticket_type, price, etc.)
 * @return int|false Ticket ID if created successfully, false otherwise
 */
function createTicket($ticket_data) {
    global $conn;
    
    // Validate required fields
    if (!isset($ticket_data['event_id']) || !isset($ticket_data['user_id']) || 
        !isset($ticket_data['ticket_type']) || !isset($ticket_data['price'])) {
        return false;
    }
    
    // Set defaults for optional fields
    $status = isset($ticket_data['status']) ? $ticket_data['status'] : 'booked';
    $payment_reference = isset($ticket_data['payment_reference']) ? $ticket_data['payment_reference'] : null;
    
    // Prepare SQL statement
    $stmt = $conn->prepare("
        INSERT INTO tickets (event_id, user_id, ticket_type, price, status, payment_reference) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("iisdss", 
        $ticket_data['event_id'], 
        $ticket_data['user_id'], 
        $ticket_data['ticket_type'], 
        $ticket_data['price'], 
        $status, 
        $payment_reference
    );
    
    if ($stmt->execute()) {
        return $conn->insert_id;
    } else {
        return false;
    }
}

/**
 * Generate QR code for a ticket
 *
 * @param int $ticket_id Ticket ID
 * @return string|false QR code filename if generated successfully, false otherwise
 */
function generateTicketQRCode($ticket_id) {
    global $conn;
    
    // Get ticket details
    $stmt = $conn->prepare("
        SELECT t.*, e.title, u.username 
        FROM tickets t
        JOIN events e ON t.event_id = e.event_id
        JOIN users u ON t.user_id = u.user_id
        WHERE t.ticket_id = ?
    ");
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows !== 1) {
        return false;
    }
    
    $ticket = $result->fetch_assoc();
    
    // Create QR code data as JSON
    $qr_data = json_encode([
        'ticket_id' => $ticket_id,
        'event_id' => $ticket['event_id'],
        'user_id' => $ticket['user_id'],
        'timestamp' => time()
    ]);
    
    // Generate a unique filename
    $filename = 'ticket_' . $ticket_id . '_' . uniqid() . '.png';
    $filepath = '../uploads/qrcodes/' . $filename;
    
    // Check if QR code library is available
    if (!function_exists('imagecreate')) {
        // Fallback if GD library is not available
        // In a real application, you would use a proper QR code library
        // For this example, we'll just create a dummy image
        
        $image = imagecreate(200, 200);
        $background = imagecolorallocate($image, 255, 255, 255);
        $text_color = imagecolorallocate($image, 0, 0, 0);
        imagestring($image, 5, 50, 90, "Ticket #" . $ticket_id, $text_color);
        imagepng($image, $filepath);
        imagedestroy($image);
    } else {
        // In a real application, use a proper QR code library like "endroid/qr-code"
        // For this example, we'll simulate QR code generation
        
        // Create a simple QR code-like image
        $image = imagecreate(200, 200);
        $background = imagecolorallocate($image, 255, 255, 255);
        $black = imagecolorallocate($image, 0, 0, 0);
        
        // Draw a border
        imagerectangle($image, 0, 0, 199, 199, $black);
        
        // Draw some random blocks to simulate QR code
        $blocks = 10;
        $block_size = 15;
        for ($i = 0; $i < $blocks; $i++) {
            for ($j = 0; $j < $blocks; $j++) {
                if (rand(0, 1)) {
                    imagefilledrectangle(
                        $image,
                        10 + $i * $block_size,
                        10 + $j * $block_size,
                        10 + ($i + 1) * $block_size,
                        10 + ($j + 1) * $block_size,
                        $black
                    );
                }
            }
        }
        
        // Add corners
        imagefilledrectangle($image, 10, 10, 40, 40, $black);
        imagefilledrectangle($image, 15, 15, 35, 35, $background);
        imagefilledrectangle($image, 20, 20, 30, 30, $black);
        
        imagefilledrectangle($image, 160, 10, 190, 40, $black);
        imagefilledrectangle($image, 165, 15, 185, 35, $background);
        imagefilledrectangle($image, 170, 20, 180, 30, $black);
        
        imagefilledrectangle($image, 10, 160, 40, 190, $black);
        imagefilledrectangle($image, 15, 165, 35, 185, $background);
        imagefilledrectangle($image, 20, 170, 30, 180, $black);
        
        // Save the image
        imagepng($image, $filepath);
        imagedestroy($image);
    }
    
    // Update ticket with QR code filename
    $stmt = $conn->prepare("UPDATE tickets SET qr_code = ? WHERE ticket_id = ?");
    $stmt->bind_param("si", $filename, $ticket_id);
    
    if ($stmt->execute()) {
        return $filename;
    } else {
        // Delete the generated file if database update fails
        if (file_exists($filepath)) {
            unlink($filepath);
        }
        return false;
    }
}

/**
 * Check in a ticket
 *
 * @param int $ticket_id Ticket ID
 * @param int $event_id Event ID (for verification)
 * @return bool True if check-in successful, false otherwise
 */
function checkInTicket($ticket_id, $event_id = null) {
    global $conn;
    
    // Get ticket details
    $stmt = $conn->prepare("SELECT * FROM tickets WHERE ticket_id = ?");
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows !== 1) {
        return false;
    }
    
    $ticket = $result->fetch_assoc();
    
    // Verify event ID if provided
    if ($event_id !== null && $ticket['event_id'] != $event_id) {
        return false;
    }
    
    // Check if ticket is already checked in
    if ($ticket['status'] === 'checked_in') {
        return false;
    }
    
    // Update ticket status
    $stmt = $conn->prepare("
        UPDATE tickets 
        SET status = 'checked_in', check_in_time = NOW() 
        WHERE ticket_id = ?
    ");
    $stmt->bind_param("i", $ticket_id);
    
    return $stmt->execute();
}

/**
 * Cancel a ticket
 *
 * @param int $ticket_id Ticket ID
 * @param int $user_id User ID (for verification)
 * @return bool True if cancellation successful, false otherwise
 */
function cancelTicket($ticket_id, $user_id) {
    global $conn;
    
    // Get ticket details
    $stmt = $conn->prepare("
        SELECT t.*, e.start_date
        FROM tickets t
        JOIN events e ON t.event_id = e.event_id
        WHERE t.ticket_id = ?
    ");
    $stmt->bind_param("i", $ticket_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows !== 1) {
        return false;
    }
    
    $ticket = $result->fetch_assoc();
    
    // Verify user owns the ticket
    if ($ticket['user_id'] != $user_id) {
        return false;
    }
    
    // Check if ticket is already checked in
    if ($ticket['status'] === 'checked_in') {
        return false;
    }
    
    // Check if event date has passed
    if (strtotime($ticket['start_date']) < time()) {
        return false;
    }
    
    // Update ticket status
    $stmt = $conn->prepare("UPDATE tickets SET status = 'cancelled' WHERE ticket_id = ?");
    $stmt->bind_param("i", $ticket_id);
    
    if ($stmt->execute()) {
        // Free up seating if applicable
        $stmt = $conn->prepare("
            UPDATE seating s
            JOIN ticket_seats ts ON s.seating_id = ts.seating_id
            SET s.status = 'available'
            WHERE ts.ticket_id = ?
        ");
        $stmt->bind_param("i", $ticket_id);
        $stmt->execute();
        
        return true;
    }
    
    return false;
}

/**
 * Get tickets for a user
 *
 * @param int $user_id User ID
 * @param string $status Optional ticket status filter
 * @return array Array of tickets
 */
function getUserTickets($user_id, $status = null) {
    global $conn;
    
    $sql = "
        SELECT t.*, e.title, e.start_date, e.end_date, e.location
        FROM tickets t
        JOIN events e ON t.event_id = e.event_id
        WHERE t.user_id = ?
    ";
    
    if ($status) {
        $sql .= " AND t.status = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $user_id, $status);
    } else {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $user_id);
    }
    
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

/**
 * Get tickets for an event
 *
 * @param int $event_id Event ID
 * @param string $status Optional ticket status filter
 * @return array Array of tickets
 */
function getEventTickets($event_id, $status = null) {
    global $conn;
    
    $sql = "
        SELECT t.*, u.username, u.email
        FROM tickets t
        JOIN users u ON t.user_id = u.user_id
        WHERE t.event_id = ?
    ";
    
    if ($status) {
        $sql .= " AND t.status = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $event_id, $status);
    } else {
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $event_id);
    }
    
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}