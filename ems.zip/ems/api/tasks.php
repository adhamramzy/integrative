<?php
/**
 * Tasks API Endpoint
 * 
 * Handles event tasks and assignments
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    jsonResponse(['error' => 'Authentication required']);
}

// Get current user
$user = getCurrentUser();
$db = getDbConnection();

// GET request to fetch tasks for an event
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Validate event ID
    if (!isset($_GET['event_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Event ID required']);
    }
    
    $eventId = (int)$_GET['event_id'];
    
    // Check if event exists
    $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event) {
        http_response_code(404);
        jsonResponse(['error' => 'Event not found']);
    }
    
    // Check if user has permission to view tasks
    $isOrganizer = ($event['organizer_id'] == $user['user_id']);
    $isAdmin = ($user['role'] === 'admin');
    $isAssigned = false;
    
    if (!$isOrganizer && !$isAdmin) {
        // Check if user is assigned to any task for this event
        $stmt = $db->prepare("
            SELECT COUNT(*) FROM tasks 
            WHERE event_id = ? AND assigned_to = ?
        ");
        $stmt->execute([$eventId, $user['user_id']]);
        $isAssigned = ($stmt->fetchColumn() > 0);
        
        if (!$isAssigned) {
            http_response_code(403);
            jsonResponse(['error' => 'You do not have permission to view tasks for this event']);
        }
        
        // If user is only assigned, only show their tasks
        $stmt = $db->prepare("
            SELECT t.*, e.title as event_title, u.username as assigned_name
            FROM tasks t
            JOIN events e ON t.event_id = e.event_id
            LEFT JOIN users u ON t.assigned_to = u.user_id
            WHERE t.event_id = ? AND t.assigned_to = ?
            ORDER BY t.due_date ASC
        ");
        $stmt->execute([$eventId, $user['user_id']]);
        $tasks = $stmt->fetchAll();
        
        jsonResponse([
            'success' => true,
            'tasks' => $tasks
        ]);
    }
    
    // For organizers and admins, show all tasks
    $stmt = $db->prepare("
        SELECT t.*, e.title as event_title, u.username as assigned_name
        FROM tasks t
        JOIN events e ON t.event_id = e.event_id
        LEFT JOIN users u ON t.assigned_to = u.user_id
        WHERE t.event_id = ?
        ORDER BY t.due_date ASC
    ");
    $stmt->execute([$eventId]);
    $tasks = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'tasks' => $tasks
    ]);
}

// POST request to create a task
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($data['event_id']) || !isset($data['title']) || !isset($data['due_date'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Missing required fields']);
    }
    
    $eventId = (int)$data['event_id'];
    $title = sanitizeInput($data['title']);
    $description = isset($data['description']) ? sanitizeInput($data['description']) : '';
    $dueDate = sanitizeInput($data['due_date']);
    $assignedTo = isset($data['assigned_to']) ? (int)$data['assigned_to'] : null;
    
    // Check if event exists
    $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event) {
        http_response_code(404);
        jsonResponse(['error' => 'Event not found']);
    }
    
    // Check if user has permission to create tasks (must be event organizer or admin)
    if ($event['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
        http_response_code(403);
        jsonResponse(['error' => 'You do not have permission to create tasks for this event']);
    }
    
    // If assigning to someone, verify the user exists
    if ($assignedTo) {
        $stmt = $db->prepare("SELECT user_id FROM users WHERE user_id = ?");
        $stmt->execute([$assignedTo]);
        if ($stmt->rowCount() === 0) {
            jsonResponse(['error' => 'Assigned user does not exist']);
        }
    }
    
    try {
        // Create the task
        $stmt = $db->prepare("
            INSERT INTO tasks (event_id, title, description, assigned_to, due_date, status)
            VALUES (?, ?, ?, ?, ?, 'pending')
        ");
        $result = $stmt->execute([$eventId, $title, $description, $assignedTo, $dueDate]);
        
        if (!$result) {
            throw new Exception('Failed to create task');
        }
        
        $taskId = $db->lastInsertId();
        
        // If task is assigned to someone, create a notification
        if ($assignedTo) {
            $stmt = $db->prepare("
                INSERT INTO notifications (user_id, event_id, message)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([
                $assignedTo,
                $eventId,
                "You have been assigned a new task: '$title' for event: '{$event['title']}'"
            ]);
        }
        
        // Log activity
        logActivity('create_task', "Created task: $title for event ID: $eventId", $user['user_id']);
        
        jsonResponse([
            'success' => true,
            'task_id' => $taskId,
            'message' => 'Task created successfully'
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to create task: ' . $e->getMessage()]);
    }
}

// PUT request to update a task
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate task ID
    if (!isset($data['task_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Task ID required']);
    }
    
    $taskId = (int)$data['task_id'];
    
    // Get the task details
    $stmt = $db->prepare("
        SELECT t.*, e.organizer_id, e.title as event_title
        FROM tasks t
        JOIN events e ON t.event_id = e.event_id
        WHERE t.task_id = ?
    ");
    $stmt->execute([$taskId]);
    $task = $stmt->fetch();
    
    if (!$task) {
        http_response_code(404);
        jsonResponse(['error' => 'Task not found']);
    }
    
    // Check if user has permission to update
    $isOrganizer = ($task['organizer_id'] == $user['user_id']);
    $isAdmin = ($user['role'] === 'admin');
    $isAssigned = ($task['assigned_to'] == $user['user_id']);
    
    // Only organizers and admins can fully update tasks
    // Assigned users can only update status
    if (!$isOrganizer && !$isAdmin && !$isAssigned) {
        http_response_code(403);
        jsonResponse(['error' => 'You do not have permission to update this task']);
    }
    
    // Prepare update data
    $updates = [];
    $params = [];
    $oldAssignedTo = $task['assigned_to'];
    $newAssignedTo = null;
    
    // Organizers and admins can update all fields
    if ($isOrganizer || $isAdmin) {
        if (isset($data['title'])) {
            $updates[] = "title = ?";
            $params[] = sanitizeInput($data['title']);
        }
        
        if (isset($data['description'])) {
            $updates[] = "description = ?";
            $params[] = sanitizeInput($data['description']);
        }
        
        if (isset($data['due_date'])) {
            $updates[] = "due_date = ?";
            $params[] = sanitizeInput($data['due_date']);
        }
        
        if (isset($data['assigned_to'])) {
            $newAssignedTo = $data['assigned_to'] ? (int)$data['assigned_to'] : null;
            
            // Verify the user exists if assigning
            if ($newAssignedTo) {
                $stmt = $db->prepare("SELECT user_id FROM users WHERE user_id = ?");
                $stmt->execute([$newAssignedTo]);
                if ($stmt->rowCount() === 0) {
                    jsonResponse(['error' => 'Assigned user does not exist']);
                }
            }
            
            $updates[] = "assigned_to = ?";
            $params[] = $newAssignedTo;
        }
    }
    
    // Anyone with permission can update status
    if (isset($data['status'])) {
        $status = sanitizeInput($data['status']);
        
        // Validate status
        $validStatuses = ['pending', 'in_progress', 'completed'];
        if (!in_array($status, $validStatuses)) {
            jsonResponse(['error' => 'Invalid status. Must be one of: ' . implode(', ', $validStatuses)]);
        }
        
        $updates[] = "status = ?";
        $params[] = $status;
    }
    
    // If no fields to update, return error
    if (empty($updates)) {
        http_response_code(400);
        jsonResponse(['error' => 'No fields to update']);
    }
    
    try {
        // Begin transaction
        $db->beginTransaction();
        
        // Add task_id to params
        $params[] = $taskId;
        
        // Update task
        $stmt = $db->prepare("UPDATE tasks SET " . implode(', ', $updates) . " WHERE task_id = ?");
        $result = $stmt->execute($params);
        
        if (!$result) {
            $db->rollBack();
            throw new Exception('Failed to update task');
        }
        
        // Handle assignment notification if assigned_to has changed
        if ($newAssignedTo && $newAssignedTo !== $oldAssignedTo) {
            // Notify the newly assigned user
            $stmt = $db->prepare("
                INSERT INTO notifications (user_id, event_id, message)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([
                $newAssignedTo,
                $task['event_id'],
                "You have been assigned a task: '{$task['title']}' for event: '{$task['event_title']}'"
            ]);
        }
        
        // Handle status change notification
        if (isset($data['status']) && $data['status'] === 'completed' && $task['status'] !== 'completed') {
            // Notify the event organizer
            $stmt = $db->prepare("
                INSERT INTO notifications (user_id, event_id, message)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([
                $task['organizer_id'],
                $task['event_id'],
                "Task '{$task['title']}' has been marked as completed"
            ]);
        }
        
        // Commit transaction
        $db->commit();
        
        // Log activity
        logActivity('update_task', "Updated task ID: $taskId", $user['user_id']);
        
        jsonResponse([
            'success' => true,
            'message' => 'Task updated successfully'
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        
        http_response_code(500);
        jsonResponse(['error' => 'Failed to update task: ' . $e->getMessage()]);
    }
}

// DELETE request to delete a task
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Validate task ID
    if (!isset($_GET['task_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Task ID required']);
    }
    
    $taskId = (int)$_GET['task_id'];
    
    // Get the task details
    $stmt = $db->prepare("
        SELECT t.*, e.organizer_id, e.title as event_title
        FROM tasks t
        JOIN events e ON t.event_id = e.event_id
        WHERE t.task_id = ?
    ");
    $stmt->execute([$taskId]);
    $task = $stmt->fetch();
    
    if (!$task) {
        http_response_code(404);
        jsonResponse(['error' => 'Task not found']);
    }
    
    // Check if user has permission to delete (only organizers and admins)
    if ($task['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
        http_response_code(403);
        jsonResponse(['error' => 'You do not have permission to delete this task']);
    }
    
    try {
        // Delete the task
        $stmt = $db->prepare("DELETE FROM tasks WHERE task_id = ?");
        $result = $stmt->execute([$taskId]);
        
        if (!$result) {
            throw new Exception('Failed to delete task');
        }
        
        // Notify assigned user if applicable
        if ($task['assigned_to']) {
            $stmt = $db->prepare("
                INSERT INTO notifications (user_id, event_id, message)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([
                $task['assigned_to'],
                $task['event_id'],
                "Task '{$task['title']}' for event '{$task['event_title']}' has been deleted"
            ]);
        }
        
        // Log activity
        logActivity('delete_task', "Deleted task ID: $taskId", $user['user_id']);
        
        jsonResponse([
            'success' => true,
            'message' => 'Task deleted successfully'
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to delete task: ' . $e->getMessage()]);
    }
}

// If we get here, it's an unsupported method
http_response_code(405);
jsonResponse(['error' => 'Method not allowed']);