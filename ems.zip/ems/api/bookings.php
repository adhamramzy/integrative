<?php
/**
 * Bookings API Endpoint
 * 
 * Handles ticket booking operations
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    jsonResponse(['error' => 'Authentication required']);
}

// Get current user
$user = getCurrentUser();
$db = getDbConnection();

// GET request to fetch user's bookings
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Get booking ID if specified for single booking
    if (isset($_GET['booking_id'])) {
        $bookingId = (int)$_GET['booking_id'];
        
        // Get the booking with event and ticket details
        $stmt = $db->prepare("
            SELECT b.*, t.ticket_type, t.price, e.title as event_title, 
                   e.start_datetime, e.end_datetime, e.location
            FROM bookings b
            JOIN tickets t ON b.ticket_id = t.ticket_id
            JOIN events e ON t.event_id = e.event_id
            WHERE b.booking_id = ? AND b.user_id = ?
        ");
        $stmt->execute([$bookingId, $user['user_id']]);
        $booking = $stmt->fetch();
        
        if ($booking) {
            jsonResponse(['success' => true, 'booking' => $booking]);
        } else {
            http_response_code(404);
            jsonResponse(['error' => 'Booking not found or does not belong to you']);
        }
    }
    
    // Get all user's bookings
    $stmt = $db->prepare("
        SELECT b.*, t.ticket_type, t.price, e.title as event_title, 
               e.start_datetime, e.end_datetime, e.location, e.event_id
        FROM bookings b
        JOIN tickets t ON b.ticket_id = t.ticket_id
        JOIN events e ON t.event_id = e.event_id
        WHERE b.user_id = ?
        ORDER BY b.booking_date DESC
    ");
    $stmt->execute([$user['user_id']]);
    $bookings = $stmt->fetchAll();
    
    jsonResponse(['success' => true, 'bookings' => $bookings]);
}

// POST request to create a booking
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($data['ticket_id']) || !isset($data['quantity'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Missing required fields']);
    }
    
    $ticketId = (int)$data['ticket_id'];
    $quantity = (int)$data['quantity'];
    
    // Validate quantity
    if ($quantity <= 0) {
        jsonResponse(['error' => 'Quantity must be a positive value']);
    }
    
    try {
        // Begin transaction
        $db->beginTransaction();
        
        // Get ticket information and check availability
        $stmt = $db->prepare("
            SELECT t.*, e.title as event_title, e.start_datetime 
            FROM tickets t
            JOIN events e ON t.event_id = e.event_id
            WHERE t.ticket_id = ?
            FOR UPDATE
        ");
        $stmt->execute([$ticketId]);
        $ticket = $stmt->fetch();
        
        if (!$ticket) {
            $db->rollBack();
            http_response_code(404);
            jsonResponse(['error' => 'Ticket not found']);
        }
        
        // Check if event date has passed
        $eventDate = new DateTime($ticket['start_datetime']);
        $currentDate = new DateTime();
        
        if ($eventDate < $currentDate) {
            $db->rollBack();
            jsonResponse(['error' => 'Cannot book tickets for past events']);
        }
        
        // Check if enough tickets are available
        if ($ticket['quantity_available'] < $quantity) {
            $db->rollBack();
            jsonResponse(['error' => 'Not enough tickets available']);
        }
        
        // Calculate total price
        $totalPrice = $ticket['price'] * $quantity;
        
        // Generate unique QR code
        $qrCode = generateQrCode($user['user_id'], $ticketId);
        
        // Create the booking
        $stmt = $db->prepare("
            INSERT INTO bookings (user_id, ticket_id, quantity, total_price, payment_status, qr_code, booking_date)
            VALUES (?, ?, ?, ?, 'pending', ?, CURRENT_TIMESTAMP)
        ");
        $result = $stmt->execute([$user['user_id'], $ticketId, $quantity, $totalPrice, $qrCode]);
        
        if (!$result) {
            $db->rollBack();
            throw new Exception('Failed to create booking');
        }
        
        $bookingId = $db->lastInsertId();
        
        // Update ticket availability
        $stmt = $db->prepare("
            UPDATE tickets 
            SET quantity_available = quantity_available - ?
            WHERE ticket_id = ?
        ");
        $result = $stmt->execute([$quantity, $ticketId]);
        
        if (!$result) {
            $db->rollBack();
            throw new Exception('Failed to update ticket availability');
        }
        
        // Simulate payment processing (in a real application this would connect to a payment gateway)
        $paymentSuccess = true; // Assume payment is successful
        
        if ($paymentSuccess) {
            // Update booking payment status to completed
            $stmt = $db->prepare("
                UPDATE bookings 
                SET payment_status = 'completed'
                WHERE booking_id = ?
            ");
            $stmt->execute([$bookingId]);
            
            // Create notification for the user
            $stmt = $db->prepare("
                INSERT INTO notifications (user_id, event_id, message)
                VALUES (?, ?, ?)
            ");
            $stmt->execute([
                $user['user_id'],
                $ticket['event_id'],
                "Your booking for {$ticket['event_title']} is confirmed. Use the QR code for check-in."
            ]);
            
            // Commit the transaction
            $db->commit();
            
            // Log activity
            logActivity('create_booking', "Booked {$quantity} tickets for event ID: {$ticket['event_id']}", $user['user_id']);
            
            jsonResponse([
                'success' => true,
                'booking_id' => $bookingId,
                'qr_code' => $qrCode,
                'message' => 'Booking confirmed successfully'
            ]);
        } else {
            // In case of payment failure
            $db->rollBack();
            jsonResponse([
                'success' => false,
                'error' => 'Payment processing failed'
            ]);
        }
    } catch (Exception $e) {
        // Rollback transaction on error
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        
        http_response_code(500);
        jsonResponse(['error' => 'Failed to create booking: ' . $e->getMessage()]);
    }
}

// PUT request to update a booking (e.g., cancel)
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate booking ID
    if (!isset($data['booking_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Booking ID required']);
    }
    
    $bookingId = (int)$data['booking_id'];
    $action = isset($data['action']) ? sanitizeInput($data['action']) : '';
    
    // Only 'cancel' action is supported for now
    if ($action !== 'cancel') {
        http_response_code(400);
        jsonResponse(['error' => 'Invalid action. Only "cancel" is supported']);
    }
    
    try {
        // Begin transaction
        $db->beginTransaction();
        
        // Get booking information
        $stmt = $db->prepare("
            SELECT b.*, t.event_id, e.start_datetime
            FROM bookings b
            JOIN tickets t ON b.ticket_id = t.ticket_id
            JOIN events e ON t.event_id = e.event_id
            WHERE b.booking_id = ? AND b.user_id = ?
            FOR UPDATE
        ");
        $stmt->execute([$bookingId, $user['user_id']]);
        $booking = $stmt->fetch();
        
        if (!$booking) {
            $db->rollBack();
            http_response_code(404);
            jsonResponse(['error' => 'Booking not found or does not belong to you']);
        }
        
        // Check if booking is already cancelled
        if ($booking['payment_status'] === 'cancelled') {
            $db->rollBack();
            jsonResponse(['error' => 'Booking is already cancelled']);
        }
        
        // Check if event date has passed or is less than 24 hours away
        $eventDate = new DateTime($booking['start_datetime']);
        $currentDate = new DateTime();
        $interval = $currentDate->diff($eventDate);
        $hoursRemaining = $interval->days * 24 + $interval->h;
        
        if ($eventDate < $currentDate) {
            $db->rollBack();
            jsonResponse(['error' => 'Cannot cancel booking for past events']);
        }
        
        if ($hoursRemaining < 24) {
            $db->rollBack();
            jsonResponse(['error' => 'Bookings can only be cancelled at least 24 hours before the event']);
        }
        
        // Cancel the booking
        $stmt = $db->prepare("
            UPDATE bookings 
            SET payment_status = 'cancelled'
            WHERE booking_id = ?
        ");
        $result = $stmt->execute([$bookingId]);
        
        if (!$result) {
            $db->rollBack();
            throw new Exception('Failed to cancel booking');
        }
        
        // Return tickets to availability
        $stmt = $db->prepare("
            UPDATE tickets 
            SET quantity_available = quantity_available + ?
            WHERE ticket_id = ?
        ");
        $result = $stmt->execute([$booking['quantity'], $booking['ticket_id']]);
        
        if (!$result) {
            $db->rollBack();
            throw new Exception('Failed to update ticket availability');
        }
        
        // Create notification for the user
        $stmt = $db->prepare("
            INSERT INTO notifications (user_id, event_id, message)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([
            $user['user_id'],
            $booking['event_id'],
            "Your booking has been cancelled successfully."
        ]);
        
        // Commit the transaction
        $db->commit();
        
        // Log activity
        logActivity('cancel_booking', "Cancelled booking ID: $bookingId", $user['user_id']);
        
        jsonResponse([
            'success' => true,
            'message' => 'Booking cancelled successfully'
        ]);
    } catch (Exception $e) {
        // Rollback transaction on error
        if ($db->inTransaction()) {
            $db->rollBack();
        }
        
        http_response_code(500);
        jsonResponse(['error' => 'Failed to cancel booking: ' . $e->getMessage()]);
    }
}

// If we get here, it's an unsupported method
http_response_code(405);
jsonResponse(['error' => 'Method not allowed']);