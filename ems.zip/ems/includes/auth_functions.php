<?php
/**
 * Authentication and authorization functions
 */

/**
 * Check if a user is logged in
 *
 * @return bool True if user is logged in, false otherwise
 */
function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check if the logged-in user has a specific role
 *
 * @param string|array $role Role or array of roles to check
 * @return bool True if user has the role, false otherwise
 */
function isUserRole($role) {
    if (!isUserLoggedIn()) {
        return false;
    }
    
    if (is_array($role)) {
        return in_array($_SESSION['role'], $role);
    } else {
        return $_SESSION['role'] === $role;
    }
}

/**
 * Authenticate user with username and password
 *
 * @param string $username Username
 * @param string $password Plain text password
 * @return array|false User data if authentication successful, false otherwise
 */
function authenticateUser($username, $password) {
    global $conn;
    
    $stmt = $conn->prepare("SELECT user_id, username, password_hash, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password_hash'])) {
            return $user;
        }
    }
    
    return false;
}

/**
 * Register a new user
 *
 * @param string $username Username
 * @param string $email Email address
 * @param string $password Plain text password
 * @param string $role User role (default: 'attendee')
 * @return int|false User ID if registration successful, false otherwise
 */
function registerUser($username, $email, $password, $role = 'attendee') {
    global $conn;
    
    // Check if username already exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        return false;
    }
    
    // Check if email already exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        return false;
    }
    
    // Hash password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    // Insert new user
    $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $email, $password_hash, $role);
    
    if ($stmt->execute()) {
        return $conn->insert_id;
    } else {
        return false;
    }
}

/**
 * Update user password
 *
 * @param int $user_id User ID
 * @param string $current_password Current password for verification
 * @param string $new_password New password
 * @return bool True if password updated, false otherwise
 */
function updatePassword($user_id, $current_password, $new_password) {
    global $conn;
    
    // Verify current password
    $stmt = $conn->prepare("SELECT password_hash FROM users WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows !== 1) {
        return false;
    }
    
    $user = $result->fetch_assoc();
    if (!password_verify($current_password, $user['password_hash'])) {
        return false;
    }
    
    // Update password
    $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password_hash = ? WHERE user_id = ?");
    $stmt->bind_param("si", $new_password_hash, $user_id);
    
    return $stmt->execute();
}