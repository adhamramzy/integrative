// Service Worker for offline functionality
const CACHE_NAME = 'ems-cache-v1';
const ASSETS_TO_CACHE = [
    '/',
    '/index.php',
    '/login.php',
    '/register.php',
    '/events.php',
    '/css/styles.css',
    '/js/main.js',
    '/js/offline.js',
    '/images/logo.png',
    '/offline.html'
];

// Install event - cache essential assets
self.addEventListener('install', event => {
    console.log('Service Worker: Installed');
    
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Service Worker: Caching Files');
                return cache.addAll(ASSETS_TO_CACHE);
            })
            .then(() => self.skipWaiting())
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', event => {
    console.log('Service Worker: Activated');
    
    // Remove old caches
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cache => {
                    if (cache !== CACHE_NAME) {
                        console.log('Service Worker: Clearing Old Cache');
                        return caches.delete(cache);
                    }
                })
            );
        })
    );
});

// Fetch event - serve cached content when offline
self.addEventListener('fetch', event => {
    console.log('Service Worker: Fetching');
    
    event.respondWith(
        // Try the network first
        fetch(event.request)
            .then(response => {
                // Clone the response
                const responseClone = response.clone();
                
                // Open cache
                caches.open(CACHE_NAME)
                    .then(cache => {
                        // Add response to cache
                        cache.put(event.request, responseClone);
                    });
                    
                return response;
            })
            .catch(() => {
                // If network fails, try the cache
                return caches.match(event.request)
                    .then(response => {
                        if (response) {
                            return response;
                        }
                        
                        // If the request is for a page, return the offline page
                        if (event.request.headers.get('accept').includes('text/html')) {
                            return caches.match('/offline.html');
                        }
                    });
            })
    );
});