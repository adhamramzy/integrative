<?php
/**
 * Notifications API Endpoint
 * 
 * Handles user notifications
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    jsonResponse(['error' => 'Authentication required']);
}

// Get current user
$user = getCurrentUser();
$db = getDbConnection();

// GET request to fetch user's notifications
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
    $unreadOnly = isset($_GET['unread']) && $_GET['unread'] === 'true';
    
    // Build query
    $query = "
        SELECT n.*, e.title as event_title
        FROM notifications n
        LEFT JOIN events e ON n.event_id = e.event_id
        WHERE n.user_id = ?
    ";
    
    $params = [$user['user_id']];
    
    // Add unread filter if requested
    if ($unreadOnly) {
        $query .= " AND n.is_read = FALSE";
    }
    
    // Add ordering and limits
    $query .= " ORDER BY n.created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $notifications = $stmt->fetchAll();
    
    // Get unread count
    $stmt = $db->prepare("
        SELECT COUNT(*) as unread_count
        FROM notifications
        WHERE user_id = ? AND is_read = FALSE
    ");
    $stmt->execute([$user['user_id']]);
    $unreadCount = $stmt->fetch()['unread_count'];
    
    jsonResponse([
        'success' => true,
        'notifications' => $notifications,
        'unread_count' => (int)$unreadCount
    ]);
}

// POST request to mark notifications as read
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Check if marking a single notification or all
    if (isset($data['notification_id'])) {
        // Mark single notification as read
        $notificationId = (int)$data['notification_id'];
        
        // Check if notification belongs to the user
        $stmt = $db->prepare("
            SELECT * FROM notifications 
            WHERE notification_id = ? AND user_id = ?
        ");
        $stmt->execute([$notificationId, $user['user_id']]);
        $notification = $stmt->fetch();
        
        if (!$notification) {
            http_response_code(404);
            jsonResponse(['error' => 'Notification not found or does not belong to you']);
        }
        
        // Mark as read
        $stmt = $db->prepare("
            UPDATE notifications 
            SET is_read = TRUE 
            WHERE notification_id = ?
        ");
        $result = $stmt->execute([$notificationId]);
        
        if ($result) {
            jsonResponse([
                'success' => true,
                'message' => 'Notification marked as read'
            ]);
        } else {
            http_response_code(500);
            jsonResponse(['error' => 'Failed to update notification']);
        }
    } elseif (isset($data['mark_all_read']) && $data['mark_all_read'] === true) {
        // Mark all user's notifications as read
        $stmt = $db->prepare("
            UPDATE notifications 
            SET is_read = TRUE 
            WHERE user_id = ? AND is_read = FALSE
        ");
        $result = $stmt->execute([$user['user_id']]);
        
        if ($result) {
            jsonResponse([
                'success' => true,
                'message' => 'All notifications marked as read'
            ]);
        } else {
            http_response_code(500);
            jsonResponse(['error' => 'Failed to update notifications']);
        }
    } else {
        http_response_code(400);
        jsonResponse(['error' => 'Missing notification_id or mark_all_read parameter']);
    }
}

// DELETE request to delete a notification
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Validate notification ID
    if (!isset($_GET['notification_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Notification ID required']);
    }
    
    $notificationId = (int)$_GET['notification_id'];
    
    // Check if notification belongs to the user
    $stmt = $db->prepare("
        SELECT * FROM notifications 
        WHERE notification_id = ? AND user_id = ?
    ");
    $stmt->execute([$notificationId, $user['user_id']]);
    $notification = $stmt->fetch();
    
    if (!$notification) {
        http_response_code(404);
        jsonResponse(['error' => 'Notification not found or does not belong to you']);
    }
    
    // Delete the notification
    $stmt = $db->prepare("DELETE FROM notifications WHERE notification_id = ?");
    $result = $stmt->execute([$notificationId]);
    
    if ($result) {
        jsonResponse([
            'success' => true,
            'message' => 'Notification deleted successfully'
        ]);
    } else {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to delete notification']);
    }
}

// If we get here, it's an unsupported method
http_response_code(405);
jsonResponse(['error' => 'Method not allowed']);