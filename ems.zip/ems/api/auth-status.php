<?php
/**
 * Auth Status API Endpoint
 * 
 * Checks if the user is authenticated and returns current session information
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (isset($_SESSION['user_id'])) {
    // Get current user information
    $user = getCurrentUser();
    
    if ($user) {
        // Return authenticated status and user info
        jsonResponse([
            'authenticated' => true,
            'user_id' => $user['user_id'],
            'username' => $user['username'],
            'role' => $_SESSION['role']
        ]);
    }
}

// If we get here, user is not authenticated
jsonResponse([
    'authenticated' => false
]);