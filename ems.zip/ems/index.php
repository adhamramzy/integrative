<?php
session_start();
require_once 'config/database.php';
require_once 'includes/utils.php';

// Get upcoming events
$stmt = $conn->prepare("
    SELECT * FROM events 
    WHERE start_date > NOW() 
    ORDER BY start_date ASC 
    LIMIT 6
");
$stmt->execute();
$upcomingEvents = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Management System</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main class="container">
        <section class="hero">
            <div class="hero-content">
                <h1>Discover and Manage Amazing Events</h1>
                <p>Plan, organize, and attend events with our comprehensive event management platform.</p>
                <?php if (!isset($_SESSION['user_id'])): ?>
                    <div class="hero-buttons">
                        <a href="register.php" class="button">Sign Up</a>
                        <a href="login.php" class="button button-secondary">Login</a>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section class="upcoming-events">
            <h2>Upcoming Events</h2>
            <div class="event-list">
                <?php foreach ($upcomingEvents as $event): ?>
                    <div class="event-card">
                        <div class="event-image" style="background-image: url('uploads/events/<?php echo $event['image'] ? htmlspecialchars($event['image']) : 'default.jpg'; ?>')"></div>
                        <div class="event-details">
                            <h3 class="event-title"><?php echo htmlspecialchars($event['title']); ?></h3>
                            <div class="event-date"><?php echo date('M d, Y', strtotime($event['start_date'])); ?></div>
                            <div class="event-location"><?php echo htmlspecialchars($event['location']); ?></div>
                            <div class="event-actions">
                                <a href="event_details.php?id=<?php echo $event['event_id']; ?>" class="button">View Details</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="view-all">
                <a href="events.php" class="button">View All Events</a>
            </div>
        </section>

        <section class="features">
            <h2>Key Features</h2>
            <div class="feature-list">
                <div class="feature-item">
                    <div class="feature-icon">📅</div>
                    <h3>Event Planning</h3>
                    <p>Create and manage events with our intuitive calendar interface.</p>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">🎟️</div>
                    <h3>Online Ticketing</h3>
                    <p>Sell tickets online with secure payment processing.</p>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">📊</div>
                    <h3>Detailed Analytics</h3>
                    <p>Track attendance and gather feedback to improve your events.</p>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">📱</div>
                    <h3>Mobile Access</h3>
                    <p>Manage events on the go with our mobile-friendly interface.</p>
                </div>
            </div>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?>
    <script src="js/offline.js"></script>
</body>
</html>