<?php
/**
 * Login API Endpoint
 * 
 * Handles user authentication and session creation
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Only allow POST method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(['error' => 'Method not allowed']);
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['username']) || !isset($data['password'])) {
    http_response_code(400);
    jsonResponse(['error' => 'Username and password required']);
}

// Sanitize inputs
$username = sanitizeInput($data['username']);
$password = $data['password']; // Don't sanitize passwords before verification

// Get database connection
$db = getDbConnection();

// Prepare statement to prevent SQL injection
$stmt = $db->prepare("SELECT user_id, username, password, role FROM users WHERE username = ?");
$stmt->execute([$username]);

$user = $stmt->fetch();

if ($user && password_verify($password, $user['password'])) {
    // Password is correct, create session
    $_SESSION['user_id'] = $user['user_id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role'] = $user['role'];
    
    // Update last login time
    $updateStmt = $db->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE user_id = ?");
    $updateStmt->execute([$user['user_id']]);
    
    // Log activity
    logActivity('login', 'User logged in successfully', $user['user_id']);
    
    // Return success response
    jsonResponse([
        'success' => true,
        'user' => [
            'username' => $user['username'],
            'role' => $user['role']
        ]
    ]);
} else {
    // Invalid credentials
    http_response_code(401);
    jsonResponse(['error' => 'Invalid username or password']);
}