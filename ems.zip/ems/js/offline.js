// Offline functionality handler
class OfflineManager {
    constructor() {
        // Check if browser supports service workers
        this.hasServiceWorker = 'serviceWorker' in navigator;
        
        // Initialize offline data storage
        this.offlineData = {
            events: [],
            tickets: [],
            tasks: [],
            feedback: []
        };
        
        // Load data from localStorage if available
        this.loadFromStorage();
        
        // Register event listeners
        this.registerListeners();
        
        // Register service worker
        if (this.hasServiceWorker) {
            this.registerServiceWorker();
        }
    }
    
    // Register service worker for offline capabilities
    registerServiceWorker() {
        navigator.serviceWorker.register('/js/sw.js')
            .then(registration => {
                console.log('Service Worker registered with scope:', registration.scope);
            })
            .catch(error => {
                console.error('Service Worker registration failed:', error);
            });
    }
    
    // Load offline data from localStorage
    loadFromStorage() {
        try {
            const storedData = localStorage.getItem('ems_offline_data');
            if (storedData) {
                this.offlineData = JSON.parse(storedData);
                console.log('Loaded offline data from storage');
            }
        } catch (error) {
            console.error('Error loading offline data:', error);
        }
    }
    
    // Save offline data to localStorage
    saveToStorage() {
        try {
            localStorage.setItem('ems_offline_data', JSON.stringify(this.offlineData));
            console.log('Saved offline data to storage');
        } catch (error) {
            console.error('Error saving offline data:', error);
        }
    }
    
    // Register online/offline event listeners
    registerListeners() {
        window.addEventListener('online', () => this.handleOnline());
        window.addEventListener('offline', () => this.handleOffline());
        
        // Check initial connection status
        if (!navigator.onLine) {
            this.handleOffline();
        }
    }
    
    // Handle when device goes offline
    handleOffline() {
        console.log('Device is offline');
        document.body.classList.add('offline-mode');
        
        // Show offline notification to user
        const offlineNotification = document.createElement('div');
        offlineNotification.className = 'offline-notification';
        offlineNotification.textContent = 'You are currently offline. Some features may be limited.';
        document.body.appendChild(offlineNotification);
        
        // Hide notification after 5 seconds
        setTimeout(() => {
            offlineNotification.classList.add('fade-out');
            setTimeout(() => offlineNotification.remove(), 1000);
        }, 5000);
    }
    
    // Handle when device comes back online
    handleOnline() {
        console.log('Device is online');
        document.body.classList.remove('offline-mode');
        
        // Sync data with server
        this.syncWithServer();
        
        // Show online notification
        const onlineNotification = document.createElement('div');
        onlineNotification.className = 'online-notification';
        onlineNotification.textContent = 'You are back online! Syncing data...';
        document.body.appendChild(onlineNotification);
        
        // Hide notification after 3 seconds
        setTimeout(() => {
            onlineNotification.classList.add('fade-out');
            setTimeout(() => onlineNotification.remove(), 1000);
        }, 3000);
    }
    
    // Add data to offline storage
    addOfflineData(type, data) {
        if (this.offlineData[type]) {
            // Add a temporary ID and timestamp
            data.temp_id = 'temp_' + new Date().getTime() + '_' + Math.random().toString(36).substr(2, 9);
            data.created_offline = new Date().toISOString();
            
            // Add to appropriate array
            this.offlineData[type].push(data);
            
            // Save to localStorage
            this.saveToStorage();
            return data.temp_id;
        }
        return null;
    }
    
    // Sync offline data with server when back online
    syncWithServer() {
        if (!navigator.onLine) {
            console.log('Cannot sync, still offline');
            return false;
        }
        
        // Process each type of offline data
        this.syncOfflineEvents();
        this.syncOfflineTickets();
        this.syncOfflineTasks();
        this.syncOfflineFeedback();
        
        return true;
    }
    
    // Sync offline events with server
    syncOfflineEvents() {
        if (this.offlineData.events.length === 0) return;
        
        console.log(`Syncing ${this.offlineData.events.length} offline events`);
        
        // Create a copy of the events array
        const eventsToSync = [...this.offlineData.events];
        
        // Clear the events array
        this.offlineData.events = [];
        this.saveToStorage();
        
        // Sync each event
        eventsToSync.forEach(event => {
            fetch('api/sync_offline_event.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(event)
            })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    console.error('Failed to sync event:', data.error);
                    // Add back to offline data if sync failed
                    this.offlineData.events.push(event);
                    this.saveToStorage();
                } else {
                    console.log('Successfully synced event:', data.event_id);
                }
            })
            .catch(error => {
                console.error('Error syncing event:', error);
                // Add back to offline data if sync failed
                this.offlineData.events.push(event);
                this.saveToStorage();
            });
        });
    }
    
    // Implementations for the other sync methods follow the same pattern
    syncOfflineTickets() { /* Similar to syncOfflineEvents */ }
    syncOfflineTasks() { /* Similar to syncOfflineEvents */ }
    syncOfflineFeedback() { /* Similar to syncOfflineEvents */ }
}

// Initialize the offline manager
const offlineManager = new OfflineManager();

// Make it available globally
window.offlineManager = offlineManager;