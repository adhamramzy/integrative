<?php
/**
 * Register API Endpoint
 * 
 * Handles new user registration
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Only allow POST method
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    jsonResponse(['error' => 'Method not allowed']);
}

// Get JSON data from request body
$data = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($data['username']) || !isset($data['email']) || !isset($data['password'])) {
    http_response_code(400);
    jsonResponse(['error' => 'Username, email and password required']);
}

// Sanitize inputs
$username = sanitizeInput($data['username']);
$email = sanitizeInput($data['email']);
$password = $data['password']; // Don't sanitize password before hashing

// Validate email format
if (!isValidEmail($email)) {
    jsonResponse(['error' => 'Invalid email format']);
}

// Validate password length
if (strlen($password) < 8) {
    jsonResponse(['error' => 'Password must be at least 8 characters long']);
}

// Validate role (default to attendee if not specified or invalid)
$allowedRoles = ['attendee', 'organizer'];
$role = isset($data['role']) && in_array($data['role'], $allowedRoles) ? $data['role'] : 'attendee';

// Get database connection
$db = getDbConnection();

// Check if username already exists
$stmt = $db->prepare("SELECT user_id FROM users WHERE username = ?");
$stmt->execute([$username]);
if ($stmt->rowCount() > 0) {
    jsonResponse(['error' => 'Username already taken']);
}

// Check if email already exists
$stmt = $db->prepare("SELECT user_id FROM users WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->rowCount() > 0) {
    jsonResponse(['error' => 'Email already registered']);
}

// Hash password
$hashedPassword = password_hash($password, PASSWORD_DEFAULT, ['cost' => HASH_COST]);

// Insert new user
try {
    $stmt = $db->prepare("INSERT INTO users (username, email, password, role, created_at) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)");
    $result = $stmt->execute([$username, $email, $hashedPassword, $role]);
    
    if ($result) {
        $userId = $db->lastInsertId();
        
        // Log activity
        logActivity('register', 'New user registration', $userId);
        
        // Return success response
        jsonResponse([
            'success' => true,
            'message' => 'Registration successful'
        ]);
    } else {
        throw new Exception('Failed to insert user record');
    }
} catch (Exception $e) {
    http_response_code(500);
    jsonResponse(['error' => 'Registration failed: ' . $e->getMessage()]);
}

?>