<?php
/**
 * Feedback API Endpoint
 * 
 * Handles event feedback and ratings
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    jsonResponse(['error' => 'Authentication required']);
}

// Get current user
$user = getCurrentUser();
$db = getDbConnection();

// GET request to fetch feedback for an event
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Validate event ID
    if (!isset($_GET['event_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Event ID required']);
    }
    
    $eventId = (int)$_GET['event_id'];
    
    // Check if event exists
    $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event) {
        http_response_code(404);
        jsonResponse(['error' => 'Event not found']);
    }
    
    // Check user's permission to view feedback
    $isOrganizer = ($event['organizer_id'] == $user['user_id']);
    $isAdmin = ($user['role'] === 'admin');
    $isAttendee = false;
    
    // Check if user attended the event
    $stmt = $db->prepare("
        SELECT b.booking_id
        FROM bookings b
        JOIN tickets t ON b.ticket_id = t.ticket_id
        WHERE t.event_id = ? AND b.user_id = ? AND b.payment_status = 'completed'
    ");
    $stmt->execute([$eventId, $user['user_id']]);
    $isAttendee = ($stmt->rowCount() > 0);
    
    // Non-organizers and non-admins can only see average ratings
    if (!$isOrganizer && !$isAdmin) {
        // Get average rating and count
        $stmt = $db->prepare("
            SELECT 
                COUNT(*) as feedback_count,
                AVG(rating) as average_rating
            FROM feedback
            WHERE event_id = ?
        ");
        $stmt->execute([$eventId]);
        $summary = $stmt->fetch();
        
        // If user is an attendee, also get their own feedback
        $userFeedback = null;
        if ($isAttendee) {
            $stmt = $db->prepare("
                SELECT * FROM feedback 
                WHERE event_id = ? AND user_id = ?
            ");
            $stmt->execute([$eventId, $user['user_id']]);
            $userFeedback = $stmt->fetch();
        }
        
        jsonResponse([
            'success' => true,
            'summary' => $summary,
            'user_feedback' => $userFeedback
        ]);
    }
    
    // Organizers and admins can see detailed feedback
    $stmt = $db->prepare("
        SELECT f.*, u.username
        FROM feedback f
        JOIN users u ON f.user_id = u.user_id
        WHERE f.event_id = ?
        ORDER BY f.submitted_at DESC
    ");
    $stmt->execute([$eventId]);
    $feedbackList = $stmt->fetchAll();
    
    // Get summary statistics
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as feedback_count,
            AVG(rating) as average_rating,
            COUNT(CASE WHEN rating = 5 THEN 1 END) as five_star,
            COUNT(CASE WHEN rating = 4 THEN 1 END) as four_star,
            COUNT(CASE WHEN rating = 3 THEN 1 END) as three_star,
            COUNT(CASE WHEN rating = 2 THEN 1 END) as two_star,
            COUNT(CASE WHEN rating = 1 THEN 1 END) as one_star
        FROM feedback
        WHERE event_id = ?
    ");
    $stmt->execute([$eventId]);
    $summary = $stmt->fetch();
    
    jsonResponse([
        'success' => true,
        'feedback' => $feedbackList,
        'summary' => $summary
    ]);
}

// POST request to submit feedback
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($data['event_id']) || !isset($data['rating'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Missing required fields']);
    }
    
    $eventId = (int)$data['event_id'];
    $rating = (int)$data['rating'];
    $comments = isset($data['comments']) ? sanitizeInput($data['comments']) : '';
    
    // Validate rating (1-5 stars)
    if ($rating < 1 || $rating > 5) {
        jsonResponse(['error' => 'Rating must be between 1 and 5']);
    }
    
    // Check if event exists
    $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event) {
        http_response_code(404);
        jsonResponse(['error' => 'Event not found']);
    }
    
    // Check if user attended the event
    $stmt = $db->prepare("
        SELECT b.booking_id
        FROM bookings b
        JOIN tickets t ON b.ticket_id = t.ticket_id
        WHERE t.event_id = ? AND b.user_id = ? AND b.payment_status = 'completed'
    ");
    $stmt->execute([$eventId, $user['user_id']]);
    
    if ($stmt->rowCount() === 0) {
        jsonResponse(['error' => 'You can only provide feedback for events you have attended']);
    }
    
    // Check if the event has ended
    $eventEnd = new DateTime($event['end_datetime']);
    $currentDate = new DateTime();
    
    if ($currentDate < $eventEnd) {
        jsonResponse(['error' => 'You can only provide feedback after the event has ended']);
    }
    
    // Check if user has already submitted feedback
    $stmt = $db->prepare("
        SELECT feedback_id FROM feedback 
        WHERE event_id = ? AND user_id = ?
    ");
    $stmt->execute([$eventId, $user['user_id']]);
    $existingFeedback = $stmt->fetch();
    
    try {
        if ($existingFeedback) {
            // Update existing feedback
            $stmt = $db->prepare("
                UPDATE feedback 
                SET rating = ?, comments = ?, submitted_at = CURRENT_TIMESTAMP
                WHERE feedback_id = ?
            ");
            $result = $stmt->execute([$rating, $comments, $existingFeedback['feedback_id']]);
            
            $message = 'Feedback updated successfully';
        } else {
            // Insert new feedback
            $stmt = $db->prepare("
                INSERT INTO feedback (event_id, user_id, rating, comments, submitted_at)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ");
            $result = $stmt->execute([$eventId, $user['user_id'], $rating, $comments]);
            
            $message = 'Feedback submitted successfully';
        }
        
        if (!$result) {
            throw new Exception('Failed to save feedback');
        }
        
        // Notify event organizer
        $stmt = $db->prepare("
            INSERT INTO notifications (user_id, event_id, message)
            VALUES (?, ?, ?)
        ");
        $stmt->execute([
            $event['organizer_id'],
            $eventId,
            "New feedback received for your event: {$event['title']}"
        ]);
        
        // Log activity
        logActivity('submit_feedback', "Submitted feedback for event ID: $eventId", $user['user_id']);
        
        jsonResponse([
            'success' => true,
            'message' => $message
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to save feedback: ' . $e->getMessage()]);
    }
}

// DELETE request to remove feedback
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Validate feedback ID
    if (!isset($_GET['feedback_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Feedback ID required']);
    }
    
    $feedbackId = (int)$_GET['feedback_id'];
    
    // Check if feedback exists and belongs to the user or if user is admin
    $stmt = $db->prepare("
        SELECT f.*, e.title as event_title
        FROM feedback f
        JOIN events e ON f.event_id = e.event_id
        WHERE f.feedback_id = ?
    ");
    $stmt->execute([$feedbackId]);
    $feedback = $stmt->fetch();
    
    if (!$feedback) {
        http_response_code(404);
        jsonResponse(['error' => 'Feedback not found']);
    }
    
    // Check if user has permission to delete
    $hasPermission = ($feedback['user_id'] == $user['user_id'] || $user['role'] === 'admin');
    
    if (!$hasPermission) {
        http_response_code(403);
        jsonResponse(['error' => 'You do not have permission to delete this feedback']);
    }
    
    try {
        // Delete the feedback
        $stmt = $db->prepare("DELETE FROM feedback WHERE feedback_id = ?");
        $result = $stmt->execute([$feedbackId]);
        
        if (!$result) {
            throw new Exception('Failed to delete feedback');
        }
        
        // Log activity
        logActivity('delete_feedback', "Deleted feedback ID: $feedbackId for event: {$feedback['event_title']}", $user['user_id']);
        
        jsonResponse([
            'success' => true,
            'message' => 'Feedback deleted successfully'
        ]);
    } catch (Exception $e) {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to delete feedback: ' . $e->getMessage()]);
    }
}

// If we get here, it's an unsupported method
http_response_code(405);
jsonResponse(['error' => 'Method not allowed']);