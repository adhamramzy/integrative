<?php
/**
 * Database Configuration
 * 
 * This file contains database connection settings and global configuration
 * for the Event Management System.
 */

// Database connection parameters
define('DB_HOST', 'localhost');     // Database host
define('DB_USER', 'root');          // Database username
define('DB_PASS', '');              // Database password (default empty for XAMPP)
define('DB_NAME', 'ems_database');  // Database name

// Application settings
define('APP_NAME', 'Event Management System');
define('APP_URL', 'http://localhost/ems'); // Update this to your actual URL
define('APP_VERSION', '1.0.0');
define('APP_EMAIL', 'admin@example.com');

// Security settings
define('SECURE_COOKIES', false);    // Set to true in production with HTTPS
define('SESSION_LIFETIME', 3600);   // Session timeout in seconds (1 hour)
define('HASH_COST', 10);            // Password hashing cost factor

// Path settings
define('ROOT_PATH', dirname(__DIR__)); // Root directory path
define('UPLOADS_PATH', ROOT_PATH . '/uploads'); // File uploads directory

/**
 * Database Connection Function
 * 
 * Creates and returns a PDO database connection with error handling
 * 
 * @return PDO Database connection object
 */
function getDbConnection() {
    try {
        // Create a new PDO instance
        $pdo = new PDO(
            'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
        
        return $pdo;
    } catch (PDOException $e) {
        // Handle connection errors
        die('Database connection failed: ' . $e->getMessage());
    }
}

/**
 * Initialize the application
 * 
 * Sets up session and basic configuration
 */
function initApp() {
    // Start or resume the session
    session_start();
    
    // Set session cookie parameters
    session_set_cookie_params([
        'lifetime' => SESSION_LIFETIME,
        'path' => '/',
        'domain' => '',
        'secure' => SECURE_COOKIES,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    
    // Set default timezone
    date_default_timezone_set('UTC');
    
    // Set error reporting based on environment (modify as needed)
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    
    // You can add more initialization code here
}

// Load helper functions
require_once __DIR__ . '/helpers.php';

// Initialize the application
initApp();