<?php
/**
 * Helper Functions
 * 
 * Common utility functions used throughout the application
 */

/**
 * Sanitizes user input
 * 
 * @param string $input The input to sanitize
 * @return string Sanitized input
 */
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate a secure random token
 * 
 * @param int $length The length of the token
 * @return string Random token
 */
function generateToken($length = 32) {
    return bin2hex(random_bytes($length / 2));
}

/**
 * Redirect to another page
 * 
 * @param string $location The URL to redirect to
 */
function redirect($location) {
    header("Location: $location");
    exit;
}

/**
 * Check if request is AJAX
 * 
 * @return bool True if request is AJAX
 */
function isAjaxRequest() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';
}

/**
 * Return JSON response
 * 
 * @param array $data The data to return
 * @param int $status HTTP status code
 */
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

/**
 * Generate a unique QR code for bookings
 * 
 * @param int $userId The user ID
 * @param int $ticketId The ticket ID
 * @return string QR code string
 */
function generateQrCode($userId, $ticketId) {
    $uniqueId = uniqid();
    $timestamp = time();
    $qrData = "EMS-{$userId}-{$ticketId}-{$uniqueId}-{$timestamp}";
    
    // You can add additional encryption or hashing if desired
    return $qrData;
}

/**
 * Format currency amount
 * 
 * @param float $amount The amount to format
 * @param string $currency The currency code (default: USD)
 * @return string Formatted currency
 */
function formatCurrency($amount, $currency = 'USD') {
    $formatter = new NumberFormatter('en_US', NumberFormatter::CURRENCY);
    return $formatter->formatCurrency($amount, $currency);
}

/**
 * Format date for display
 * 
 * @param string $date Date string
 * @param string $format Format string (default: Y-m-d H:i)
 * @return string Formatted date
 */
function formatDate($date, $format = 'Y-m-d H:i') {
    $datetime = new DateTime($date);
    return $datetime->format($format);
}

/**
 * Get current user from session
 * 
 * @return array|null User data or null if not logged in
 */
function getCurrentUser() {
    if (isset($_SESSION['user_id'])) {
        // Get database connection
        $db = getDbConnection();
        
        // Prepare and execute the query
        $stmt = $db->prepare("SELECT user_id, username, email, role FROM users WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        
        // Fetch the user
        $user = $stmt->fetch();
        
        if ($user) {
            return $user;
        }
    }
    
    return null;
}

/**
 * Check if user is logged in
 * 
 * @return bool True if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if user has specific role
 * 
 * @param string|array $roles Role or array of roles to check
 * @return bool True if user has the role
 */
function hasRole($roles) {
    if (!isLoggedIn()) {
        return false;
    }
    
    // Make sure roles is an array
    if (!is_array($roles)) {
        $roles = [$roles];
    }
    
    // Check if the user's role is in the allowed roles
    return in_array($_SESSION['role'], $roles);
}

/**
 * Log system activity
 * 
 * @param string $action The action being performed
 * @param string $details Details about the action
 * @param int $userId The user performing the action (or null)
 */
function logActivity($action, $details, $userId = null) {
    if ($userId === null && isset($_SESSION['user_id'])) {
        $userId = $_SESSION['user_id'];
    }
    
    $db = getDbConnection();
    $stmt = $db->prepare("INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    $stmt->execute([$userId, $action, $details, $ipAddress]);
}

/**
 * Validate email address
 * 
 * @param string $email Email address to validate
 * @return bool True if email is valid
 */
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Get base URL of the application
 * 
 * @return string Base URL
 */
function getBaseUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];
    $scriptName = dirname($_SERVER['SCRIPT_NAME']);
    
    // Remove any trailing slashes
    $baseUrl = rtrim("$protocol://$host$scriptName", '/');
    
    return $baseUrl;
}