<?php
/**
 * Tickets API Endpoint
 * 
 * Handles ticket types and operations
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    jsonResponse(['error' => 'Authentication required']);
}

// Get current user
$user = getCurrentUser();
$db = getDbConnection();

// GET request to fetch tickets
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Validate event ID
    if (!isset($_GET['event_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Event ID required']);
    }
    
    $eventId = (int)$_GET['event_id'];
    
    // Check if event exists
    $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event) {
        http_response_code(404);
        jsonResponse(['error' => 'Event not found']);
    }
    
    // Get tickets for the event
    $stmt = $db->prepare("SELECT * FROM tickets WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $tickets = $stmt->fetchAll();
    
    jsonResponse([
        'success' => true,
        'tickets' => $tickets
    ]);
}

// POST request to create a ticket type
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($data['event_id']) || !isset($data['ticket_type']) || 
        !isset($data['price']) || !isset($data['quantity_available'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Missing required fields']);
    }
    
    $eventId = (int)$data['event_id'];
    $ticketType = sanitizeInput($data['ticket_type']);
    $price = (float)$data['price'];
    $quantityAvailable = (int)$data['quantity_available'];
    
    // Validate price and quantity
    if ($price < 0) {
        jsonResponse(['error' => 'Price must be a non-negative value']);
    }
    
    if ($quantityAvailable <= 0) {
        jsonResponse(['error' => 'Quantity must be a positive value']);
    }
    
    // Check if event exists
    $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event) {
        http_response_code(404);
        jsonResponse(['error' => 'Event not found']);
    }
    
    // Check if user has permission (must be event organizer or admin)
    if ($event['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
        http_response_code(403);
        jsonResponse(['error' => 'Forbidden. You do not have permission to create tickets for this event']);
    }
    
    // Check if a ticket type with the same name already exists for this event
    $stmt = $db->prepare("SELECT * FROM tickets WHERE event_id = ? AND ticket_type = ?");
    $stmt->execute([$eventId, $ticketType]);
    
    if ($stmt->rowCount() > 0) {
        jsonResponse(['error' => 'A ticket type with this name already exists for this event']);
    }
    
    try {
        // Create the ticket type
        $stmt = $db->prepare("INSERT INTO tickets (event_id, ticket_type, price, quantity_available) 
                           VALUES (?, ?, ?, ?)");
        $result = $stmt->execute([$eventId, $ticketType, $price, $quantityAvailable]);
        
        if ($result) {
            $ticketId = $db->lastInsertId();
            
            // Log activity
            logActivity('create_ticket', "Created ticket type: $ticketType for event ID: $eventId", $user['user_id']);
            
            jsonResponse([
                'success' => true,
                'ticket_id' => $ticketId,
                'message' => 'Ticket type created successfully'
            ]);
        } else {
            throw new Exception('Failed to create ticket type');
        }
    } catch (Exception $e) {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to create ticket type: ' . $e->getMessage()]);
    }
}

// PUT request to update a ticket type
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate ticket ID
    if (!isset($data['ticket_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Ticket ID required']);
    }
    
    $ticketId = (int)$data['ticket_id'];
    
    // Check if ticket exists
    $stmt = $db->prepare("
        SELECT t.*, e.organizer_id 
        FROM tickets t
        JOIN events e ON t.event_id = e.event_id
        WHERE t.ticket_id = ?
    ");
    $stmt->execute([$ticketId]);
    $ticket = $stmt->fetch();
    
    if (!$ticket) {
        http_response_code(404);
        jsonResponse(['error' => 'Ticket not found']);
    }
    
    // Check if user has permission (must be event organizer or admin)
    if ($ticket['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
        http_response_code(403);
        jsonResponse(['error' => 'Forbidden. You do not have permission to update this ticket']);
    }
    
    // Prepare update data
    $updates = [];
    $params = [];
    
    // Update fields if they exist in request
    if (isset($data['ticket_type'])) {
        $updates[] = "ticket_type = ?";
        $params[] = sanitizeInput($data['ticket_type']);
    }
    
    if (isset($data['price'])) {
        $price = (float)$data['price'];
        if ($price < 0) {
            jsonResponse(['error' => 'Price must be a non-negative value']);
        }
        $updates[] = "price = ?";
        $params[] = $price;
    }
    
    if (isset($data['quantity_available'])) {
        $quantity = (int)$data['quantity_available'];
        if ($quantity <= 0) {
            jsonResponse(['error' => 'Quantity must be a positive value']);
        }
        $updates[] = "quantity_available = ?";
        $params[] = $quantity;
    }
    
    // If no fields to update, return error
    if (empty($updates)) {
        http_response_code(400);
        jsonResponse(['error' => 'No fields to update']);
    }
    
    try {
        // Add ticket_id to params
        $params[] = $ticketId;
        
        // Update ticket
        $stmt = $db->prepare("UPDATE tickets SET " . implode(', ', $updates) . " WHERE ticket_id = ?");
        $result = $stmt->execute($params);
        
        if ($result) {
            // Log activity
            logActivity('update_ticket', "Updated ticket ID: $ticketId", $user['user_id']);
            
            jsonResponse([
                'success' => true,
                'message' => 'Ticket updated successfully'
            ]);
        } else {
            throw new Exception('Failed to update ticket');
        }
    } catch (Exception $e) {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to update ticket: ' . $e->getMessage()]);
    }
}

// DELETE request to delete a ticket type
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Validate ticket ID
    if (!isset($_GET['ticket_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Ticket ID required']);
    }
    
    $ticketId = (int)$_GET['ticket_id'];
    
    // Check if ticket exists and get event organizer
    $stmt = $db->prepare("
        SELECT t.*, e.organizer_id 
        FROM tickets t
        JOIN events e ON t.event_id = e.event_id
        WHERE t.ticket_id = ?
    ");
    $stmt->execute([$ticketId]);
    $ticket = $stmt->fetch();
    
    if (!$ticket) {
        http_response_code(404);
        jsonResponse(['error' => 'Ticket not found']);
    }
    
    // Check if user has permission (must be event organizer or admin)
    if ($ticket['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
        http_response_code(403);
        jsonResponse(['error' => 'Forbidden. You do not have permission to delete this ticket']);
    }
    
    // Check if there are any bookings for this ticket
    $stmt = $db->prepare("SELECT COUNT(*) FROM bookings WHERE ticket_id = ?");
    $stmt->execute([$ticketId]);
    $bookingsCount = $stmt->fetchColumn();
    
    if ($bookingsCount > 0) {
        http_response_code(409);
        jsonResponse(['error' => 'Cannot delete ticket. There are bookings associated with this ticket type']);
    }
    
    try {
        // Delete the ticket
        $stmt = $db->prepare("DELETE FROM tickets WHERE ticket_id = ?");
        $result = $stmt->execute([$ticketId]);
        
        if ($result) {
            // Log activity
            logActivity('delete_ticket', "Deleted ticket ID: $ticketId", $user['user_id']);
            
            jsonResponse([
                'success' => true,
                'message' => 'Ticket deleted successfully'
            ]);
        } else {
            throw new Exception('Failed to delete ticket');
        }
    } catch (Exception $e) {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to delete ticket: ' . $e->getMessage()]);
    }
}

// If we get here, it's an unsupported method
http_response_code(405);
jsonResponse(['error' => 'Method not allowed']);