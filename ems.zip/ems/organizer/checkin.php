<?php
session_start();
require_once '../config/database.php';
require_once '../includes/auth_functions.php';

// Check if user is logged in and is an organizer
if (!isUserLoggedIn() || !isUserRole('organizer')) {
    header("Location: ../login.php");
    exit();
}

// Get events organized by the current user
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("
    SELECT event_id, title, start_date, location 
    FROM events 
    WHERE created_by = ? AND start_date >= CURDATE()
    ORDER BY start_date ASC
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$events_result = $stmt->get_result();
$events = $events_result->fetch_all(MYSQLI_ASSOC);

// Get selected event
$selectedEvent = isset($_GET['event_id']) ? intval($_GET['event_id']) : 0;

// Get recent check-ins if event is selected
$recentCheckins = [];
if ($selectedEvent > 0) {
    $stmt = $conn->prepare("
        SELECT t.ticket_id, t.check_in_time, u.username, t.ticket_type
        FROM tickets t
        JOIN users u ON t.user_id = u.user_id
        WHERE t.event_id = ? AND t.status = 'checked_in'
        ORDER BY t.check_in_time DESC
        LIMIT 10
    ");
    $stmt->bind_param("i", $selectedEvent);
    $stmt->execute();
    $recentCheckins = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Check-in - EMS</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container">
        <h1>Event Check-in</h1>
        
        <div class="event-selector">
            <form action="checkin.php" method="GET">
                <div class="form-group">
                    <label for="event-select">Select Event:</label>
                    <select id="event-select" name="event_id" onchange="this.form.submit()">
                        <option value="">-- Select an Event --</option>
                        <?php foreach ($events as $event): ?>
                            <option value="<?php echo $event['event_id']; ?>" <?php echo $selectedEvent == $event['event_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($event['title']); ?> (<?php echo date('M d, Y', strtotime($event['start_date'])); ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </form>
        </div>
        
        <?php if ($selectedEvent > 0): ?>
            <div class="checkin-container">
                <div class="card">
                    <div class="card-header">
                        <h2>Scan QR Code</h2>
                    </div>
                    <div class="card-body">
                        <div class="scanner-container">
                            <div id="scanner"></div>
                            <div class="scanner-controls">
                                <button id="startScanner" class="button">Start Scanner</button>
                                <button id="stopScanner" class="button button-danger" disabled>Stop Scanner</button>
                            </div>
                        </div>
                        
                        <div class="manual-entry">
                            <h3>Or Enter Ticket ID Manually</h3>
                            <form id="manualCheckinForm">
                                <input type="hidden" id="eventId" value="<?php echo $selectedEvent; ?>">
                                <div class="form-group">
                                    <input type="text" id="ticketId" name="ticketId" placeholder="Enter Ticket ID">
                                    <button type="submit" class="button">Check In</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <h2>Check-in Results</h2>
                    </div>
                    <div class="card-body">
                        <div id="checkinResult" class="hidden">
                            <!-- Check-in results will be displayed here -->
                        </div>
                        
                        <div class="recent-checkins">
                            <h3>Recent Check-ins</h3>
                            <div id="recentCheckins">
                                <?php if (count($recentCheckins) > 0): ?>
                                    <ul class="checkin-list">
                                        <?php foreach ($recentCheckins as $checkin): ?>
                                            <li class="checkin-item">
                                                <div class="checkin-status success">✓</div>
                                                <div class="checkin-info">
                                                    <div class="checkin-ticket">Ticket #<?php echo $checkin['ticket_id']; ?></div>
                                                    <div class="checkin-name"><?php echo htmlspecialchars($checkin['username']); ?></div>
                                                    <div class="checkin-time"><?php echo date('h:i:s A', strtotime($checkin['check_in_time'])); ?></div>
                                                </div>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php else: ?>
                                    <p>No recent check-ins.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="card-body">
                    <p>Please select an event to start the check-in process.</p>
                </div>
            </div>
        <?php endif; ?>
    </main>
    <?php include '../includes/footer.php'; ?>
    <script src="https://unpkg.com/html5-qrcode"></script>
    <script src="../js/offline.js"></script>
    <script src="../js/checkin.js"></script>
</body>
</html>