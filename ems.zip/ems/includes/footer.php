<footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Event Management System</h3>
                <p>Plan, organize, and attend events with our comprehensive platform.</p>
            </div>
            
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="<?php echo getBaseUrl(); ?>index.php">Home</a></li>
                    <li><a href="<?php echo getBaseUrl(); ?>events.php">Events</a></li>
                    <li><a href="<?php echo getBaseUrl(); ?>about.php">About Us</a></li>
                    <li><a href="<?php echo getBaseUrl(); ?>contact.php">Contact</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h3>Contact Us</h3>
                <p>Email: info@ems-example.com</p>
                <p>Phone: +1 (123) 456-7890</p>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Event Management System. All rights reserved.</p>
        </div>
    </div>
</footer>

<script>
    // Mobile menu toggle
    document.addEventListener('DOMContentLoaded', function() {
        const hamburger = document.querySelector('.hamburger');
        const navMenu = document.querySelector('.nav-menu');
        
        if (hamburger) {
            hamburger.addEventListener('click', function() {
                navMenu.classList.toggle('active');
            });
        }
        
        // Auto-hide alerts after 5 seconds
        const alerts = document.querySelectorAll('.success-alert, .error-alert');
        alerts.forEach(function(alert) {
            setTimeout(function() {
                alert.style.opacity = '0';
                setTimeout(function() {
                    alert.style.display = 'none';
                }, 500);
            }, 5000);
        });
    });
</script>