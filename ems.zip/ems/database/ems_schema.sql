-- Create database
DROP DATABASE IF EXISTS ems_db;
CREATE DATABASE ems_db;
USE ems_db;

-- Users table
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role ENUM('admin', 'organizer', 'attendee') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Events table
CREATE TABLE events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    start_date DATETIME NOT NULL,
    end_date DATETIME NOT NULL,
    location VARCHAR(255) NOT NULL,
    image VARCHAR(255),
    created_by INT,
    status ENUM('upcoming', 'ongoing', 'completed', 'cancelled') DEFAULT 'upcoming',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id)
);

-- Ticket types table
CREATE TABLE ticket_types (
    ticket_type_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    ticket_type VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    max_tickets INT NOT NULL,
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);

-- Tickets table
CREATE TABLE tickets (
    ticket_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    ticket_type VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    qr_code VARCHAR(255),
    status ENUM('booked', 'paid', 'checked_in', 'cancelled') DEFAULT 'booked',
    payment_reference VARCHAR(100),
    purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    check_in_time DATETIME,
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Tasks table
CREATE TABLE tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    assigned_to INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    deadline DATETIME NOT NULL,
    status ENUM('pending', 'in_progress', 'completed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (assigned_to) REFERENCES users(user_id)
);

-- Feedback table
CREATE TABLE feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    user_id INT NOT NULL,
    rating INT NOT NULL,
    comments TEXT,
    submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(event_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Seating table
CREATE TABLE seating (
    seating_id INT AUTO_INCREMENT PRIMARY KEY,
    event_id INT NOT NULL,
    section VARCHAR(50) NOT NULL,
    row VARCHAR(10) NOT NULL,
    seat_number INT NOT NULL,
    status ENUM('available', 'reserved', 'occupied') DEFAULT 'available',
    FOREIGN KEY (event_id) REFERENCES events(event_id)
);

-- Ticket seats table (many-to-many relationship)
CREATE TABLE ticket_seats (
    ticket_seat_id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT NOT NULL,
    seating_id INT NOT NULL,
    FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id),
    FOREIGN KEY (seating_id) REFERENCES seating(seating_id)
);

-- Notifications table
CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    related_to VARCHAR(50) NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- Create trigger for automatic notification on event creation
DELIMITER $$
CREATE TRIGGER after_event_insert
AFTER INSERT ON events
FOR EACH ROW
BEGIN
    INSERT INTO notifications (user_id, message, related_to)
    SELECT user_id, CONCAT('New event: ', NEW.title, ' has been created.'), 'event'
    FROM users
    WHERE role = 'attendee';
END$$
DELIMITER ;

-- Create trigger for automatic notification on ticket purchase
DELIMITER $$
CREATE TRIGGER after_ticket_insert
AFTER INSERT ON tickets
FOR EACH ROW
BEGIN
    -- Get event details
    DECLARE event_title VARCHAR(100);
    
    SELECT title INTO event_title
    FROM events
    WHERE event_id = NEW.event_id;
    
    -- Notify ticket purchaser
    INSERT INTO notifications (user_id, message, related_to)
    VALUES (NEW.user_id, CONCAT('Your ticket for ', event_title, ' has been confirmed.'), 'ticket');
    
    -- Notify event organizer
    INSERT INTO notifications (user_id, message, related_to)
    SELECT created_by, CONCAT('New ticket purchased for ', event_title), 'ticket'
    FROM events
    WHERE event_id = NEW.event_id;
END$$
DELIMITER ;

-- Insert sample admin user
INSERT INTO users (username, password_hash, email, role) VALUES 
('admin', '$2y$10$8jbJJI9YeSGoOLwgKenMzuGiP0MNLk7eP5UyBJiY0P7UAtELOycJq', 'admin@example.com', 'admin');
-- Default password: admin123