<?php
session_start();
require_once '../config/database.php';
require_once '../includes/auth_functions.php';

// Check if user is logged in and is an organizer
if (!isUserLoggedIn() || !isUserRole('organizer')) {
    header("Location: ../login.php");
    exit();
}

$success_message = "";
$error_message = "";

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $location = $_POST['location'];
    $created_by = $_SESSION['user_id'];
    
    // Validate input
    if (empty($title) || empty($start_date) || empty($end_date) || empty($location)) {
        $error_message = "All required fields must be filled.";
    } else if (strtotime($end_date) <= strtotime($start_date)) {
        $error_message = "End date must be after start date.";
    } else {
        // Process image upload if provided
        $image = null;
        if (isset($_FILES['image']) && $_FILES['image']['size'] > 0) {
            $target_dir = "../uploads/events/";
            $file_extension = pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION);
            $image = uniqid() . "." . $file_extension;
            $target_file = $target_dir . $image;
            
            // Check file size and type
            $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
            if ($_FILES["image"]["size"] > 5000000) { // 5MB limit
                $error_message = "File is too large. Maximum size is 5MB.";
            } else if (!in_array(strtolower($file_extension), $allowed_types)) {
                $error_message = "Only JPG, JPEG, PNG & GIF files are allowed.";
            } else if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                $error_message = "Error uploading file.";
            }
        }
        
        if (empty($error_message)) {
            // Insert event into database
            $stmt = $conn->prepare("INSERT INTO events (title, description, start_date, end_date, location, image, created_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssi", $title, $description, $start_date, $end_date, $location, $image, $created_by);
            
            if ($stmt->execute()) {
                $event_id = $conn->insert_id;
                $success_message = "Event created successfully!";
                
                // Redirect to event details page after a short delay
                header("refresh:2;url=event_details.php?id=" . $event_id);
            } else {
                $error_message = "Error creating event: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Event - EMS</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container">
        <h1>Create New Event</h1>
        
        <?php if ($success_message): ?>
            <div class="success-alert"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
            <div class="error-alert"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-body">
                <form method="POST" action="create_event.php" enctype="multipart/form-data" data-validate="true">
                    <div class="form-group">
                        <label for="title">Event Title *</label>
                        <input type="text" id="title" name="title" data-validate="required" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" rows="4"></textarea>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group half">
                            <label for="start_date">Start Date & Time *</label>
                            <input type="datetime-local" id="start_date" name="start_date" data-validate="required" required>
                        </div>
                        
                        <div class="form-group half">
                            <label for="end_date">End Date & Time *</label>
                            <input type="datetime-local" id="end_date" name="end_date" data-validate="required" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="location">Location *</label>
                        <input type="text" id="location" name="location" data-validate="required" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="image">Event Image</label>
                        <input type="file" id="image" name="image" accept="image/*">
                        <small>Recommended size: 1200x600 pixels. Max file size: 5MB.</small>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="button">Create Event</button>
                        <a href="events.php" class="button button-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>
    <script src="../js/validation.js"></script>
    <script src="../js/event.js"></script>
</body>
</html>