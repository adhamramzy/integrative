// Service Worker for Offline Support in EMS

const CACHE_NAME = 'ems-cache-v1';
const urlsToCache = [
    '/',
    '/index.html',
    '/login.html',
    '/register.html',
    '/dashboard.html',
    '/events.html',
    '/tickets.html',
    '/check-in.html',
    '/profile.html',
    '/offline.html',
    '/assets/css/style.css',
    '/assets/js/main.js',
    '/assets/js/api.js',
    '/assets/js/offline.js',
    '/assets/img/logo.png',
    '/assets/img/event-placeholder.jpg',
    '/assets/img/user-placeholder.png',
    'https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.4/html5-qrcode.min.js'
];

// Install event - cache important files
self.addEventListener('install', function(event) {
    console.log('Service Worker installing');
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(function(cache) {
                console.log('Service Worker caching app shell');
                return cache.addAll(urlsToCache);
            })
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', function(event) {
    console.log('Service Worker activating');
    event.waitUntil(
        caches.keys().then(function(cacheNames) {
            return Promise.all(
                cacheNames.map(function(cacheName) {
                    if (cacheName !== CACHE_NAME) {
                        console.log('Service Worker clearing old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
    return self.clients.claim();
});

// Fetch event - serve cached content when offline
self.addEventListener('fetch', function(event) {
    // Skip for some cross-origin requests (like CDN resources)
    if (event.request.url.startsWith(self.location.origin) || event.request.url.includes('chart.googleapis.com')) {
        event.respondWith(
            caches.match(event.request)
                .then(function(response) {
                    // Return cached response if found
                    if (response) {
                        return response;
                    }
                    
                    // Otherwise, get from network
                    return fetch(event.request)
                        .then(function(networkResponse) {
                            // Don't cache API responses
                            if (event.request.url.includes('/api/')) {
                                return networkResponse;
                            }
                            
                            // Clone the response to store in cache and return
                            const responseToCache = networkResponse.clone();
                            
                            caches.open(CACHE_NAME)
                                .then(function(cache) {
                                    cache.put(event.request, responseToCache);
                                });
                                
                            return networkResponse;
                        })
                        .catch(function(error) {
                            console.log('Fetch failed:', error);
                            
                            // For API requests, return a custom offline response
                            if (event.request.url.includes('/api/')) {
                                return new Response(JSON.stringify({
                                    error: 'You are offline. This request will be processed when you are back online.'
                                }), {
                                    headers: { 'Content-Type': 'application/json' }
                                });
                            }
                            
                            // If it's a page request, show the offline page
                            if (event.request.mode === 'navigate') {
                                return caches.match('/offline.html');
                            }
                            
                            // Default error response
                            return new Response('Network error occurred', {
                                status: 503,
                                statusText: 'Service Unavailable'
                            });
                        });
                })
        );
    }
});

// Handle the sync event for background syncing
self.addEventListener('sync', function(event) {
    if (event.tag === 'sync-checkins') {
        event.waitUntil(syncCheckins());
    } else if (event.tag === 'sync-feedback') {
        event.waitUntil(syncFeedback());
    }
});

// Function to sync check-ins in the background
function syncCheckins() {
    return new Promise((resolve, reject) => {
        // This would normally access IndexedDB and sync data
        // For simplicity, we're just logging the attempt
        console.log('Background sync: attempting to sync check-ins');
        
        // In a real implementation, you would:
        // 1. Open IndexedDB and get pendingCheckins
        // 2. Send them to the server via fetch
        // 3. Update their status in IndexedDB when successful
        
        resolve(); // Always resolve to avoid keeping the sync event hanging
    });
}

// Function to sync feedback in the background
function syncFeedback() {
    return new Promise((resolve, reject) => {
        console.log('Background sync: attempting to sync feedback');
        // Similar to syncCheckins, but for feedback data
        resolve();
    });
}