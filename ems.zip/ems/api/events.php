<?php
/**
 * Events API Endpoint
 * 
 * Handles event CRUD operations
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    jsonResponse(['error' => 'Authentication required']);
}

// Get current user
$user = getCurrentUser();
$db = getDbConnection();

// GET request to fetch events
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $offset = isset($_GET['offset']) ? (int)$_GET['offset'] : 0;
    $organizerId = isset($_GET['organizer_id']) ? (int)$_GET['organizer_id'] : null;
    
    // If event_id is specified, get a single event
    if (isset($_GET['event_id'])) {
        $eventId = (int)$_GET['event_id'];
        
        $stmt = $db->prepare("SELECT e.*, u.username as organizer_name 
                           FROM events e 
                           JOIN users u ON e.organizer_id = u.user_id 
                           WHERE e.event_id = ?");
        $stmt->execute([$eventId]);
        $event = $stmt->fetch();
        
        if ($event) {
            jsonResponse(['success' => true, 'event' => $event]);
        } else {
            http_response_code(404);
            jsonResponse(['error' => 'Event not found']);
        }
    }
    
    // Build query based on parameters
    $query = "SELECT e.*, u.username as organizer_name 
              FROM events e 
              JOIN users u ON e.organizer_id = u.user_id";
    
    $params = [];
    $whereConditions = [];
    
    // Filter by organizer if specified
    if ($organizerId) {
        $whereConditions[] = "e.organizer_id = ?";
        $params[] = $organizerId;
    }
    
    // Add WHERE clause if there are conditions
    if (!empty($whereConditions)) {
        $query .= " WHERE " . implode(' AND ', $whereConditions);
    }
    
    // Add ordering and limits
    $query .= " ORDER BY e.start_datetime ASC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $events = $stmt->fetchAll();
    
    jsonResponse(['success' => true, 'events' => $events]);
}

// POST request to create an event
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Only organizers and admins can create events
    if ($user['role'] !== 'organizer' && $user['role'] !== 'admin') {
        http_response_code(403);
        jsonResponse(['error' => 'Forbidden. Only organizers and admins can create events']);
    }
    
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate required fields
    if (!isset($data['title']) || !isset($data['location']) || 
        !isset($data['start_datetime']) || !isset($data['end_datetime'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Missing required fields']);
    }
    
    // Sanitize inputs
    $title = sanitizeInput($data['title']);
    $description = isset($data['description']) ? sanitizeInput($data['description']) : '';
    $location = sanitizeInput($data['location']);
    $startDatetime = sanitizeInput($data['start_datetime']);
    $endDatetime = sanitizeInput($data['end_datetime']);
    $maxCapacity = isset($data['max_capacity']) ? (int)$data['max_capacity'] : null;
    $status = isset($data['status']) ? sanitizeInput($data['status']) : 'draft';
    
    try {
        // Insert new event
        $stmt = $db->prepare("INSERT INTO events (title, description, location, start_datetime, end_datetime, 
                           max_capacity, organizer_id, status, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
        
        $result = $stmt->execute([
            $title, $description, $location, $startDatetime, $endDatetime,
            $maxCapacity, $user['user_id'], $status
        ]);
        
        if ($result) {
            $eventId = $db->lastInsertId();
            
            // Log activity
            logActivity('create_event', "Created event: $title", $user['user_id']);
            
            jsonResponse([
                'success' => true,
                'event_id' => $eventId,
                'message' => 'Event created successfully'
            ]);
        } else {
            throw new Exception('Failed to create event');
        }
    } catch (Exception $e) {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to create event: ' . $e->getMessage()]);
    }
}

// PUT request to update an event
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Get JSON data from request body
    $data = json_decode(file_get_contents('php://input'), true);
    
    // Validate event ID
    if (!isset($data['event_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Event ID required']);
    }
    
    $eventId = (int)$data['event_id'];
    
    // Check if event exists
    $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event) {
        http_response_code(404);
        jsonResponse(['error' => 'Event not found']);
    }
    
    // Check if user has permission to update (must be organizer or admin)
    if ($event['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
        http_response_code(403);
        jsonResponse(['error' => 'Forbidden. You do not have permission to update this event']);
    }
    
    // Prepare update data
    $updates = [];
    $params = [];
    
    // Update fields if they exist in request
    if (isset($data['title'])) {
        $updates[] = "title = ?";
        $params[] = sanitizeInput($data['title']);
    }
    
    if (isset($data['description'])) {
        $updates[] = "description = ?";
        $params[] = sanitizeInput($data['description']);
    }
    
    if (isset($data['location'])) {
        $updates[] = "location = ?";
        $params[] = sanitizeInput($data['location']);
    }
    
    if (isset($data['start_datetime'])) {
        $updates[] = "start_datetime = ?";
        $params[] = sanitizeInput($data['start_datetime']);
    }
    
    if (isset($data['end_datetime'])) {
        $updates[] = "end_datetime = ?";
        $params[] = sanitizeInput($data['end_datetime']);
    }
    
    if (isset($data['max_capacity'])) {
        $updates[] = "max_capacity = ?";
        $params[] = (int)$data['max_capacity'];
    }
    
    if (isset($data['status'])) {
        $updates[] = "status = ?";
        $params[] = sanitizeInput($data['status']);
    }
    
    // Add updated_at timestamp
    $updates[] = "updated_at = CURRENT_TIMESTAMP";
    
    // If no fields to update, return error
    if (empty($updates)) {
        http_response_code(400);
        jsonResponse(['error' => 'No fields to update']);
    }
    
    try {
        // Add event_id to params
        $params[] = $eventId;
        
        // Update event
        $stmt = $db->prepare("UPDATE events SET " . implode(', ', $updates) . " WHERE event_id = ?");
        $result = $stmt->execute($params);
        
        if ($result) {
            // Log activity
            logActivity('update_event', "Updated event ID: $eventId", $user['user_id']);
            
            jsonResponse([
                'success' => true,
                'message' => 'Event updated successfully'
            ]);
        } else {
            throw new Exception('Failed to update event');
        }
    } catch (Exception $e) {
        http_response_code(500);
        jsonResponse(['error' => 'Failed to update event: ' . $e->getMessage()]);
    }
}

// DELETE request to delete an event
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Validate event ID
    if (!isset($_GET['event_id'])) {
        http_response_code(400);
        jsonResponse(['error' => 'Event ID required']);
    }
    
    $eventId = (int)$_GET['event_id'];
    
    // Check if event exists
    $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    if (!$event) {
        http_response_code(404);
        jsonResponse(['error' => 'Event not found']);
    }
    
    // Check if user has permission to delete (must be organizer or admin)
    if ($event['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
        http_response_code(403);
        jsonResponse(['error' => 'Forbidden. You do not have permission to delete this event']);
    }
    
    try {
        // Begin transaction
        $db->beginTransaction();
        
        // Delete all associated tickets first
        $stmt = $db->prepare("DELETE FROM tickets WHERE event_id = ?");
        $stmt->execute([$eventId]);
        
        // Delete the event
        $stmt = $db->prepare("DELETE FROM events WHERE event_id = ?");
        $result = $stmt->execute([$eventId]);
        
        if ($result) {
            // Commit transaction
            $db->commit();
            
            // Log activity
            logActivity('delete_event', "Deleted event ID: $eventId", $user['user_id']);
            
            jsonResponse([
                'success' => true,
                'message' => 'Event deleted successfully'
            ]);
        } else {
            throw new Exception('Failed to delete event');
        }
    } catch (Exception $e) {
        // Rollback transaction on error
        $db->rollBack();
        
        http_response_code(500);
        jsonResponse(['error' => 'Failed to delete event: ' . $e->getMessage()]);
    }
}

// If we get here, it's an unsupported method
http_response_code(405);
jsonResponse(['error' => 'Method not allowed']);