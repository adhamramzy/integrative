<?php
session_start();
require_once '../config/database.php';
require_once '../includes/auth_functions.php';
require_once '../includes/ticket_functions.php';

// Check if user is logged in and is an attendee
if (!isUserLoggedIn() || !isUserRole('attendee')) {
    header("Location: ../login.php");
    exit();
}

// Check if event ID is provided
if (!isset($_GET['event_id']) || !is_numeric($_GET['event_id'])) {
    header("Location: events.php");
    exit();
}

$event_id = intval($_GET['event_id']);

// Get event details
$stmt = $conn->prepare("SELECT * FROM events WHERE event_id = ?");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$event_result = $stmt->get_result();

if ($event_result->num_rows !== 1) {
    header("Location: events.php");
    exit();
}

$event = $event_result->fetch_assoc();

// Check if event date has passed
if (strtotime($event['start_date']) < time()) {
    $_SESSION['error_message'] = "This event has already started and tickets are no longer available.";
    header("Location: event_details.php?id=" . $event_id);
    exit();
}

// Get ticket types and prices for this event
$stmt = $conn->prepare("
    SELECT ticket_type, price, 
           (SELECT COUNT(*) FROM tickets WHERE event_id = ? AND ticket_type = t.ticket_type) as sold,
           max_tickets
    FROM ticket_types t
    WHERE event_id = ?
");
$stmt->bind_param("ii", $event_id, $event_id);
$stmt->execute();
$ticket_types_result = $stmt->get_result();
$ticket_types = $ticket_types_result->fetch_all(MYSQLI_ASSOC);

// Process form submission
$success_message = "";
$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ticket_type = $_POST['ticket_type'];
    $quantity = intval($_POST['quantity']);
    $payment_method = $_POST['payment_method'];
    
    // Validate input
    if (empty($ticket_type) || $quantity <= 0) {
        $error_message = "Please select a valid ticket type and quantity.";
    } else {
        // Find the selected ticket type
        $selected_type = null;
        foreach ($ticket_types as $type) {
            if ($type['ticket_type'] === $ticket_type) {
                $selected_type = $type;
                break;
            }
        }
        
        if (!$selected_type) {
            $error_message = "Invalid ticket type selected.";
        } else if ($selected_type['sold'] + $quantity > $selected_type['max_tickets']) {
            $error_message = "Sorry, there are not enough tickets available.";
        } else {
            // Calculate total price
            $price = $selected_type['price'];
            $total_price = $price * $quantity;
            
            // Create payment transaction (simplified)
            $payment_reference = "PAY-" . uniqid();
            
            // Create tickets
            $created_tickets = [];
            for ($i = 0; $i < $quantity; $i++) {
                $ticket_data = [
                    'event_id' => $event_id,
                    'user_id' => $_SESSION['user_id'],
                    'ticket_type' => $ticket_type,
                    'price' => $price,
                    'payment_reference' => $payment_reference,
                    'status' => 'paid'
                ];
                
                $ticket_id = createTicket($ticket_data);
                if ($ticket_id) {
                    // Generate QR code for the ticket
                    $qr_code = generateTicketQRCode($ticket_id);
                    
                    // Update ticket with QR code
                    $stmt = $conn->prepare("UPDATE tickets SET qr_code = ? WHERE ticket_id = ?");
                    $stmt->bind_param("si", $qr_code, $ticket_id);
                    $stmt->execute();
                    
                    $created_tickets[] = $ticket_id;
                }
            }
            
            if (count($created_tickets) === $quantity) {
                $success_message = "Your tickets have been booked successfully!";
                
                // Redirect to the first ticket
                header("refresh:2;url=view_ticket.php?id=" . $created_tickets[0]);
            } else {
                $error_message = "There was an error booking some tickets.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Tickets - <?php echo htmlspecialchars($event['title']); ?></title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container">
        <h1>Book Tickets</h1>
        <h2><?php echo htmlspecialchars($event['title']); ?></h2>
        <p class="event-details">
            <span class="event-date"><?php echo date('F d, Y', strtotime($event['start_date'])); ?></span>
            <span class="event-time"><?php echo date('h:i A', strtotime($event['start_date'])); ?> - <?php echo date('h:i A', strtotime($event['end_date'])); ?></span>
            <span class="event-location"><?php echo htmlspecialchars($event['location']); ?></span>
        </p>
        
        <?php if ($success_message): ?>
            <div class="success-alert"><?php echo $success_message; ?></div>
        <?php endif; ?>
        
        <?php if ($error_message): ?>
            <div class="error-alert"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-body">
                <form method="POST" action="book_ticket.php?event_id=<?php echo $event_id; ?>" data-validate="true">
                    <div class="form-group">
                        <label for="ticket_type">Ticket Type</label>
                        <select id="ticket_type" name="ticket_type" data-validate="required" required>
                            <option value="">-- Select Ticket Type --</option>
                            <?php foreach ($ticket_types as $type): ?>
                                <?php if ($type['sold'] < $type['max_tickets']): ?>
                                    <option value="<?php echo $type['ticket_type']; ?>" data-price="<?php echo $type['price']; ?>">
                                        <?php echo ucfirst($type['ticket_type']); ?> - $<?php echo $type['price']; ?>
                                    </option>
                                <?php else: ?>
                                    <option value="<?php echo $type['ticket_type']; ?>" disabled>
                                        <?php echo ucfirst($type['ticket_type']); ?> - SOLD OUT
                                    </option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="quantity">Quantity</label>
                        <select id="quantity" name="quantity" data-validate="required" required>
                            <?php for ($i = 1; $i <= 10; $i++): ?>
                                <option value="<?php echo $i; ?>"><?php echo $i; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <h3>Total: $<span id="totalPrice">0.00</span></h3>
                    </div>
                    
                    <div class="form-group">
                        <label>Payment Method</label>
                        <div class="payment-methods">
                            <label class="payment-method">
                                <input type="radio" name="payment_method" value="paypal" checked>
                                <img src="../images/paypal.png" alt="PayPal">
                                <span>PayPal</span>
                            </label>
                            <label class="payment-method">
                                <input type="radio" name="payment_method" value="credit_card">
                                <img src="../images/credit-card.png" alt="Credit Card">
                                <span>Credit Card</span>
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="button">Complete Purchase</button>
                        <a href="event_details.php?id=<?php echo $event_id; ?>" class="button button-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>
    <script src="../js/validation.js"></script>
    <script>
        // Update total price based on ticket type and quantity
        document.addEventListener('DOMContentLoaded', function() {
            const ticketTypeSelect = document.getElementById('ticket_type');
            const quantitySelect = document.getElementById('quantity');
            const totalPriceElement = document.getElementById('totalPrice');
            
            function updateTotalPrice() {
                const selectedOption = ticketTypeSelect.options[ticketTypeSelect.selectedIndex];
                const price = selectedOption ? parseFloat(selectedOption.dataset.price || 0) : 0;
                const quantity = parseInt(quantitySelect.value);
                const totalPrice = price * quantity;
                
                totalPriceElement.textContent = totalPrice.toFixed(2);
            }
            
            ticketTypeSelect.addEventListener('change', updateTotalPrice);
            quantitySelect.addEventListener('change', updateTotalPrice);
            
            // Initial calculation
            updateTotalPrice();
        });
    </script>
</body>
</html>