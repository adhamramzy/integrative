// Offline Support for EMS

// IndexedDB for Offline Data Storage
class OfflineStorage {
    constructor() {
        this.dbName = 'emsOfflineDB';
        this.dbVersion = 1;
        this.db = null;
        this.initDB();
    }
    
    // Initialize the database
    initDB() {
        const request = indexedDB.open(this.dbName, this.dbVersion);
        
        request.onerror = (event) => {
            console.error('Error opening offline database:', event.target.error);
        };
        
        request.onsuccess = (event) => {
            this.db = event.target.result;
            console.log('Offline database opened successfully');
            this.syncDataWhenOnline();
        };
        
        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            
            // Create object stores for offline data
            if (!db.objectStoreNames.contains('pendingCheckins')) {
                db.createObjectStore('pendingCheckins', { keyPath: 'id', autoIncrement: true });
            }
            
            if (!db.objectStoreNames.contains('cachedEvents')) {
                db.createObjectStore('cachedEvents', { keyPath: 'event_id' });
            }
            
            if (!db.objectStoreNames.contains('cachedBookings')) {
                db.createObjectStore('cachedBookings', { keyPath: 'booking_id' });
            }
            
            if (!db.objectStoreNames.contains('pendingFeedback')) {
                db.createObjectStore('pendingFeedback', { keyPath: 'id', autoIncrement: true });
            }
            
            console.log('Database setup complete');
        };
    }
    
    // Store check-in data when offline
    storeCheckIn(qrData) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['pendingCheckins'], 'readwrite');
            const store = transaction.objectStore('pendingCheckins');
            const checkin = {
                qrCode: qrData,
                timestamp: new Date().toISOString(),
                synced: false
            };
            
            const request = store.add(checkin);
            
            request.onsuccess = () => {
                resolve(true);
            };
            
            request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    
    // Store feedback when offline
    storeFeedback(eventId, rating, comments) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction(['pendingFeedback'], 'readwrite');
            const store = transaction.objectStore('pendingFeedback');
            const feedback = {
                event_id: eventId,
                rating: rating,
                comments: comments,
                timestamp: new Date().toISOString(),
                synced: false
            };
            
            const request = store.add(feedback);
            
            request.onsuccess = () => {
                resolve(true);
            };
            
            request.onerror = (event) => {
                reject(event.target.error);
            };
        });
    }
    
    // Store data for offline use
    cacheData(storeName, data) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readwrite');
            const store = transaction.objectStore(storeName);
            
            // If data is an array, add each item
            if (Array.isArray(data)) {
                let count = 0;
                data.forEach(item => {
                    const request = store.put(item);
                    request.onsuccess = () => {
                        count++;
                        if (count === data.length) {
                            resolve(true);
                        }
                    };
                    request.onerror = (event) => {
                        reject(event.target.error);
                    };
                });
            } else {
                // If data is a single object
                const request = store.put(data);
                request.onsuccess = () => {
                    resolve(true);
                };
                request.onerror = (event) => {
                    reject(event.target.error);
                };
            }
        });
    }
    
    // Get cached data
    getCachedData(storeName, key = null) {
        return new Promise((resolve, reject) => {
            const transaction = this.db.transaction([storeName], 'readonly');
            const store = transaction.objectStore(storeName);
            
            if (key) {
                // Get a specific item
                const request = store.get(key);
                request.onsuccess = () => {
                    resolve(request.result);
                };
                request.onerror = (event) => {
                    reject(event.target.error);
                };
            } else {
                // Get all items
                const items = [];
                const request = store.openCursor();
                
                request.onsuccess = (event) => {
                    const cursor = event.target.result;
                    if (cursor) {
                        items.push(cursor.value);
                        cursor.continue();
                    } else {
                        resolve(items);
                    }
                };
                
                request.onerror = (event) => {
                    reject(event.target.error);
                };
            }
        });
    }
    
    // Sync data with server when online
    syncDataWhenOnline() {
        window.addEventListener('online', () => {
            this.syncPendingCheckins();
            this.syncPendingFeedback();
        });
        
        // Also try to sync immediately if already online
        if (navigator.onLine) {
            this.syncPendingCheckins();
            this.syncPendingFeedback();
        }
    }
    
    // Sync pending check-ins with server
    syncPendingCheckins() {
        this.getCachedData('pendingCheckins')
            .then(checkins => {
                // Filter unsynchronized check-ins
                const pendingCheckins = checkins.filter(checkin => !checkin.synced);
                
                pendingCheckins.forEach(checkin => {
                    fetch('/api/checkin.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ qr_code: checkin.qrCode }),
                        credentials: 'include'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Mark as synced in IndexedDB
                            const transaction = this.db.transaction(['pendingCheckins'], 'readwrite');
                            const store = transaction.objectStore('pendingCheckins');
                            checkin.synced = true;
                            store.put(checkin);
                            
                            console.log('Successfully synced check-in:', checkin.id);
                        } else {
                            console.warn('Failed to sync check-in:', data.error);
                        }
                    })
                    .catch(error => {
                        console.error('Error syncing check-in:', error);
                    });
                });
            })
            .catch(error => {
                console.error('Error retrieving pending check-ins:', error);
            });
    }
    
    // Sync pending feedback with server
    syncPendingFeedback() {
        this.getCachedData('pendingFeedback')
            .then(feedbacks => {
                // Filter unsynchronized feedback
                const pendingFeedbacks = feedbacks.filter(feedback => !feedback.synced);
                
                pendingFeedbacks.forEach(feedback => {
                    fetch('/api/feedback.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            event_id: feedback.event_id,
                            rating: feedback.rating,
                            comments: feedback.comments
                        }),
                        credentials: 'include'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Mark as synced in IndexedDB
                            const transaction = this.db.transaction(['pendingFeedback'], 'readwrite');
                            const store = transaction.objectStore('pendingFeedback');
                            feedback.synced = true;
                            store.put(feedback);
                            
                            console.log('Successfully synced feedback:', feedback.id);
                        } else {
                            console.warn('Failed to sync feedback:', data.error);
                        }
                    })
                    .catch(error => {
                        console.error('Error syncing feedback:', error);
                    });
                });
            })
            .catch(error => {
                console.error('Error retrieving pending feedback:', error);
            });
    }
    
    // Cache events for offline viewing
    cacheEvents() {
        if (navigator.onLine) {
            fetch('/api/events.php', {
                method: 'GET',
                credentials: 'include'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.events) {
                    this.cacheData('cachedEvents', data.events);
                    console.log('Events cached for offline use');
                }
            })
            .catch(error => {
                console.error('Error caching events:', error);
            });
        }
    }
    
    // Cache user's bookings for offline viewing
    cacheBookings() {
        if (navigator.onLine) {
            fetch('/api/bookings.php', {
                method: 'GET',
                credentials: 'include'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.bookings) {
                    this.cacheData('cachedBookings', data.bookings);
                    console.log('Bookings cached for offline use');
                }
            })
            .catch(error => {
                console.error('Error caching bookings:', error);
            });
        }
    }
}

// Initialize offline storage
const offlineStorage = new OfflineStorage();

// Service Worker Registration for Offline Support
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js').then(function(registration) {
            console.log('ServiceWorker registration successful with scope: ', registration.scope);
        }, function(err) {
            console.log('ServiceWorker registration failed: ', err);
        });
    });
}

// Function to handle network status and provide offline capability
function handleNetworkStatus() {
    const isOnline = navigator.onLine;
    
    // Update UI based on network status
    const networkStatus = document.getElementById('network-status');
    if (networkStatus) {
        networkStatus.textContent = isOnline ? 'Online' : 'Offline';
        networkStatus.style.color = isOnline ? '#3c763d' : '#a94442';
    }
    
    // Show/hide offline notification banner
    const offlineBanner = document.getElementById('offline-banner');
    if (offlineBanner) {
        offlineBanner.style.display = isOnline ? 'none' : 'block';
    }
    
    // If coming back online, sync data
    if (isOnline) {
        if (offlineStorage.db) {
            offlineStorage.syncPendingCheckins();
            offlineStorage.syncPendingFeedback();
        }
    }
    
    // If going offline, ensure we have cached data
    if (!isOnline) {
        if (offlineStorage.db) {
            // Check if we have cached the data already
            offlineStorage.getCachedData('cachedEvents').then(events => {
                if (!events || events.length === 0) {
                    console.log('No cached events found. Cache will be updated when back online.');
                }
            });
        }
    }
    
    return isOnline;
}

// Check network status on page load
window.addEventListener('load', function() {
    handleNetworkStatus();
    
    // Cache critical data for offline use
    if (offlineStorage.db) {
        offlineStorage.cacheEvents();
        offlineStorage.cacheBookings();
    }
});

// Listen for online/offline events
window.addEventListener('online', handleNetworkStatus);
window.addEventListener('offline', handleNetworkStatus);

// Function to get data with offline fallback
async function getDataWithOfflineFallback(apiEndpoint, cachedStoreName) {
    if (navigator.onLine) {
        try {
            // Try to get fresh data from API
            const response = await fetch(apiEndpoint, {
                method: 'GET',
                credentials: 'include'
            });
            const data = await response.json();
            
            // If successful, cache the data and return it
            if (data.success) {
                if (offlineStorage.db && data.events) {
                    offlineStorage.cacheData(cachedStoreName, data.events);
                } else if (offlineStorage.db && data.bookings) {
                    offlineStorage.cacheData(cachedStoreName, data.bookings);
                }
                return data;
            } else {
                throw new Error(data.error || 'API request failed');
            }
        } catch (error) {
            console.error('Error fetching data:', error);
            // Fall back to cached data on error
            if (offlineStorage.db) {
                const cachedData = await offlineStorage.getCachedData(cachedStoreName);
                if (cachedData && cachedData.length > 0) {
                    return { success: true, [cachedStoreName === 'cachedEvents' ? 'events' : 'bookings']: cachedData };
                }
            }
            throw error; // Re-throw if no cached data
        }
    } else {
        // Offline mode - use cached data
        if (offlineStorage.db) {
            const cachedData = await offlineStorage.getCachedData(cachedStoreName);
            if (cachedData && cachedData.length > 0) {
                return { success: true, [cachedStoreName === 'cachedEvents' ? 'events' : 'bookings']: cachedData };
            } else {
                throw new Error('No cached data available offline');
            }
        } else {
            throw new Error('Offline database not available');
        }
    }
}