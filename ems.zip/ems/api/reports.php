<?php
/**
 * Reports API Endpoint
 * 
 * Handles analytics and reporting for events
 */

// Include configuration and helpers
require_once '../includes/config.php';

// Set content type to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(401);
    jsonResponse(['error' => 'Authentication required']);
}

// Get current user
$user = getCurrentUser();
$db = getDbConnection();

// Only organizers and admins can access reports
if ($user['role'] !== 'organizer' && $user['role'] !== 'admin') {
    http_response_code(403);
    jsonResponse(['error' => 'Forbidden. Only organizers and admins can access reports']);
}

// GET request to fetch event reports
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Check if event ID is provided
    if (isset($_GET['event_id'])) {
        $eventId = (int)$_GET['event_id'];
        
        // Check if event exists
        $stmt = $db->prepare("SELECT * FROM events WHERE event_id = ?");
        $stmt->execute([$eventId]);
        $event = $stmt->fetch();
        
        if (!$event) {
            http_response_code(404);
            jsonResponse(['error' => 'Event not found']);
        }
        
        // Check if user has permission (must be event organizer or admin)
        if ($event['organizer_id'] != $user['user_id'] && $user['role'] !== 'admin') {
            http_response_code(403);
            jsonResponse(['error' => 'You do not have permission to view reports for this event']);
        }
        
        // Get event details
        $eventData = [
            'event_id' => $event['event_id'],
            'title' => $event['title'],
            'location' => $event['location'],
            'start_datetime' => $event['start_datetime'],
            'end_datetime' => $event['end_datetime'],
            'max_capacity' => $event['max_capacity'],
            'status' => $event['status']
        ];
        
        // Get attendance report
        $attendanceReport = getEventAttendanceReport($db, $eventId);
        
        // Get tickets breakdown
        $ticketsBreakdown = getTicketsBreakdown($db, $eventId);
        
        // Get feedback summary
        $feedbackSummary = getEventFeedbackSummary($db, $eventId);
        
        // Generate the complete report
        $report = [
            'event' => $eventData,
            'attendance' => $attendanceReport,
            'tickets' => $ticketsBreakdown,
            'feedback' => $feedbackSummary
        ];
        
        jsonResponse([
            'success' => true,
            'report' => $report
        ]);
    } elseif (isset($_GET['user_id']) && ($user['role'] === 'admin' || $user['user_id'] == $_GET['user_id'])) {
        // User reports (admin can see any user's reports, users can see their own)
        $userId = (int)$_GET['user_id'];
        
        // Get user's events (if organizer)
        $stmt = $db->prepare("
            SELECT * FROM events 
            WHERE organizer_id = ?
            ORDER BY start_datetime DESC
        ");
        $stmt->execute([$userId]);
        $events = $stmt->fetchAll();
        
        // Get user's bookings (for any user)
        $stmt = $db->prepare("
            SELECT b.*, t.ticket_type, e.title as event_title, e.start_datetime
            FROM bookings b
            JOIN tickets t ON b.ticket_id = t.ticket_id
            JOIN events e ON t.event_id = e.event_id
            WHERE b.user_id = ?
            ORDER BY b.booking_date DESC
        ");
        $stmt->execute([$userId]);
        $bookings = $stmt->fetchAll();
        
        jsonResponse([
            'success' => true,
            'events' => $events,
            'bookings' => $bookings
        ]);
    } else {
        // If no specific report is requested, return a summary of all events for the organizer
        $stmt = $db->prepare("
            SELECT 
                e.event_id, 
                e.title, 
                e.start_datetime, 
                e.status,
                COUNT(DISTINCT b.booking_id) as total_bookings,
                SUM(b.quantity) as tickets_sold,
                SUM(b.total_price) as revenue
            FROM events e
            LEFT JOIN tickets t ON e.event_id = t.event_id
            LEFT JOIN bookings b ON t.ticket_id = b.ticket_id AND b.payment_status = 'completed'
            WHERE e.organizer_id = ?
            GROUP BY e.event_id
            ORDER BY e.start_datetime DESC
        ");
        $stmt->execute([$user['user_id']]);
        $eventsSummary = $stmt->fetchAll();
        
        jsonResponse([
            'success' => true,
            'events_summary' => $eventsSummary
        ]);
    }
}

// Function to get event attendance report
function getEventAttendanceReport($db, $eventId) {
    $stmt = $db->prepare("
        SELECT 
            COUNT(DISTINCT b.booking_id) as total_bookings,
            SUM(b.quantity) as total_tickets_sold,
            COUNT(DISTINCT ci.check_in_id) as total_checked_in,
            (CASE WHEN SUM(b.quantity) > 0 
                THEN (COUNT(DISTINCT ci.check_in_id) * 100.0 / SUM(b.quantity)) 
                ELSE 0 
            END) as check_in_rate,
            SUM(b.total_price) as total_revenue
        FROM tickets t
        LEFT JOIN bookings b ON t.ticket_id = b.ticket_id AND b.payment_status = 'completed'
        LEFT JOIN check_ins ci ON b.booking_id = ci.booking_id
        WHERE t.event_id = ?
    ");
    $stmt->execute([$eventId]);
    $report = $stmt->fetch();
    
    // Add hourly check-in breakdown if event date has passed
    $stmt = $db->prepare("
        SELECT * FROM events WHERE event_id = ?
    ");
    $stmt->execute([$eventId]);
    $event = $stmt->fetch();
    
    $eventDate = new DateTime($event['start_datetime']);
    $currentDate = new DateTime();
    
    if ($currentDate > $eventDate) {
        $stmt = $db->prepare("
            SELECT 
                DATE_FORMAT(ci.check_in_time, '%H:00') as hour,
                COUNT(ci.check_in_id) as check_ins
            FROM check_ins ci
            JOIN bookings b ON ci.booking_id = b.booking_id
            JOIN tickets t ON b.ticket_id = t.ticket_id
            WHERE t.event_id = ?
            GROUP BY DATE_FORMAT(ci.check_in_time, '%H:00')
            ORDER BY hour
        ");
        $stmt->execute([$eventId]);
        $hourlyBreakdown = $stmt->fetchAll();
        
        $report['hourly_breakdown'] = $hourlyBreakdown;
    }
    
    return $report;
}

// Function to get tickets breakdown
function getTicketsBreakdown($db, $eventId) {
    $stmt = $db->prepare("
        SELECT 
            t.ticket_id,
            t.ticket_type,
            t.price,
            t.quantity_available,
            COUNT(b.booking_id) as bookings_count,
            SUM(b.quantity) as tickets_sold,
            SUM(b.total_price) as revenue
        FROM tickets t
        LEFT JOIN bookings b ON t.ticket_id = b.ticket_id AND b.payment_status = 'completed'
        WHERE t.event_id = ?
        GROUP BY t.ticket_id
    ");
    $stmt->execute([$eventId]);
    return $stmt->fetchAll();
}

// Function to get event feedback summary
function getEventFeedbackSummary($db, $eventId) {
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total_feedback,
            AVG(rating) as average_rating,
            COUNT(CASE WHEN rating = 5 THEN 1 END) as five_star,
            COUNT(CASE WHEN rating = 4 THEN 1 END) as four_star,
            COUNT(CASE WHEN rating = 3 THEN 1 END) as three_star,
            COUNT(CASE WHEN rating = 2 THEN 1 END) as two_star,
            COUNT(CASE WHEN rating = 1 THEN 1 END) as one_star
        FROM feedback
        WHERE event_id = ?
    ");
    $stmt->execute([$eventId]);
    $summary = $stmt->fetch();
    
    // Include recent comments
    $stmt = $db->prepare("
        SELECT f.rating, f.comments, f.submitted_at, u.username
        FROM feedback f
        JOIN users u ON f.user_id = u.user_id
        WHERE f.event_id = ? AND f.comments != ''
        ORDER BY f.submitted_at DESC
        LIMIT 5
    ");
    $stmt->execute([$eventId]);
    $recentComments = $stmt->fetchAll();
    
    $summary['recent_comments'] = $recentComments;
    
    return $summary;
}

// If we get here, it's an unsupported method
http_response_code(405);
jsonResponse(['error' => 'Method not allowed']);