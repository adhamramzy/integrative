<header>
    <div class="container">
        <nav class="navbar">
            <div class="logo">EMS</div>
            
            <div class="hamburger">
                <div class="line"></div>
                <div class="line"></div>
                <div class="line"></div>
            </div>
            
            <ul class="nav-menu">
                <li><a href="<?php echo getBaseUrl(); ?>index.php">Home</a></li>
                <li><a href="<?php echo getBaseUrl(); ?>events.php">Events</a></li>
                
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li><a href="<?php echo getBaseUrl(); ?>admin/dashboard.php">Dashboard</a></li>
                        <li><a href="<?php echo getBaseUrl(); ?>admin/users.php">Users</a></li>
                    <?php elseif ($_SESSION['role'] === 'organizer'): ?>
                        <li><a href="<?php echo getBaseUrl(); ?>organizer/dashboard.php">Dashboard</a></li>
                        <li><a href="<?php echo getBaseUrl(); ?>organizer/events.php">My Events</a></li>
                        <li><a href="<?php echo getBaseUrl(); ?>organizer/create_event.php">Create Event</a></li>
                    <?php else: ?>
                        <li><a href="<?php echo getBaseUrl(); ?>attendee/my_tickets.php">My Tickets</a></li>
                    <?php endif; ?>
                    
                    <li><a href="<?php echo getBaseUrl(); ?>profile.php">Profile</a></li>
                    <li><a href="<?php echo getBaseUrl(); ?>logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="<?php echo getBaseUrl(); ?>login.php">Login</a></li>
                    <li><a href="<?php echo getBaseUrl(); ?>register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>

<?php if (isset($_SESSION['success_message'])): ?>
    <div class="container">
        <div class="success-alert">
            <?php 
                echo $_SESSION['success_message'];
                unset($_SESSION['success_message']);
            ?>
        </div>
    </div>
<?php endif; ?>

<?php if (isset($_SESSION['error_message'])): ?>
    <div class="container">
        <div class="error-alert">
            <?php 
                echo $_SESSION['error_message'];
                unset($_SESSION['error_message']);
            ?>
        </div>
    </div>
<?php endif; ?>

<?php
// Helper function to get base URL
function getBaseUrl() {
    $current_path = $_SERVER['PHP_SELF'];
    $path_parts = explode('/', $current_path);
    
    // Remove file name and potentially parent directory
    array_pop($path_parts);
    
    if (in_array('admin', $path_parts) || in_array('organizer', $path_parts) || in_array('attendee', $path_parts)) {
        return '../';
    } else {
        return '';
    }
}
?>