<?php
session_start();
require_once '../config/database.php';
require_once '../includes/auth_functions.php';

// Check if user is logged in and is an organizer
if (!isUserLoggedIn() || !isUserRole('organizer')) {
    header("Location: ../login.php");
    exit();
}

// Check if event ID is provided
if (!isset($_GET['event_id']) || !is_numeric($_GET['event_id'])) {
    header("Location: events.php");
    exit();
}

$event_id = intval($_GET['event_id']);
$user_id = $_SESSION['user_id'];

// Check if user is the organizer of this event
$stmt = $conn->prepare("SELECT * FROM events WHERE event_id = ? AND created_by = ?");
$stmt->bind_param("ii", $event_id, $user_id);
$stmt->execute();
$event_result = $stmt->get_result();

if ($event_result->num_rows !== 1) {
    $_SESSION['error_message'] = "You don't have permission to view analytics for this event.";
    header("Location: events.php");
    exit();
}

$event = $event_result->fetch_assoc();

// Get ticket sales statistics
$stmt = $conn->prepare("
    SELECT 
        ticket_type, 
        COUNT(*) as count, 
        SUM(price) as total_revenue 
    FROM tickets 
    WHERE event_id = ? 
    GROUP BY ticket_type
");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$ticket_stats = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Get feedback statistics
$stmt = $conn->prepare("
    SELECT 
        AVG(rating) as avg_rating, 
        COUNT(*) as total_feedback 
    FROM feedback 
    WHERE event_id = ?
");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$feedback_stats = $stmt->get_result()->fetch_assoc();

// Get attendee check-in statistics
$stmt = $conn->prepare("
    SELECT 
        COUNT(CASE WHEN status = 'checked_in' THEN 1 END) as checked_in,
        COUNT(*) as total_tickets
    FROM tickets 
    WHERE event_id = ?
");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$checkin_stats = $stmt->get_result()->fetch_assoc();

// Get feedback rating distribution
$stmt = $conn->prepare("
    SELECT rating, COUNT(*) as count
    FROM feedback 
    WHERE event_id = ?
    GROUP BY rating
    ORDER BY rating
");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$feedback_distribution = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Initialize ratings array (1-5)
$ratings = [0, 0, 0, 0, 0];

// Fill in actual counts
foreach ($feedback_distribution as $item) {
    $rating = intval($item['rating']);
    if ($rating >= 1 && $rating <= 5) {
        $ratings[$rating - 1] = intval($item['count']);
    }
}

// Get check-in distribution by hour
$stmt = $conn->prepare("
    SELECT 
        HOUR(check_in_time) as hour,
        COUNT(*) as count
    FROM tickets
    WHERE event_id = ? AND status = 'checked_in'
    GROUP BY HOUR(check_in_time)
    ORDER BY hour
");
$stmt->bind_param("i", $event_id);
$stmt->execute();
$checkin_distribution = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Analytics - <?php echo htmlspecialchars($event['title']); ?></title>
    <link rel="stylesheet" href="../css/styles.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <main class="container">
        <h1>Analytics for: <?php echo htmlspecialchars($event['title']); ?></h1>
        
        <div class="stats-overview">
            <div class="stat-card">
                <h3>Ticket Sales</h3>
                <div class="stat-value"><?php echo count($ticket_stats) > 0 ? array_sum(array_column($ticket_stats, 'count')) : 0; ?></div>
            </div>
            <div class="stat-card">
                <h3>Revenue</h3>
                <div class="stat-value">$<?php echo count($ticket_stats) > 0 ? number_format(array_sum(array_column($ticket_stats, 'total_revenue')), 2) : '0.00'; ?></div>
            </div>
            <div class="stat-card">
                <h3>Average Rating</h3>
                <div class="stat-value"><?php echo $feedback_stats['avg_rating'] ? number_format($feedback_stats['avg_rating'], 1) : 'N/A'; ?> / 5</div>
            </div>
            <div class="stat-card">
                <h3>Check-in Rate</h3>
                <div class="stat-value">
                    <?php 
                    echo $checkin_stats['total_tickets'] > 0 
                        ? number_format(($checkin_stats['checked_in'] / $checkin_stats['total_tickets']) * 100, 1) . '%' 
                        : 'N/A'; 
                    ?>
                </div>
            </div>
        </div>
        
        <div class="analytics-tabs">
            <div class="tab-buttons">
                <button class="analytics-tab active" data-target="sales-tab">Sales</button>
                <button class="analytics-tab" data-target="attendees-tab">Attendees</button>
                <button class="analytics-tab" data-target="feedback-tab">Feedback</button>
            </div>
            
            <div class="tab-content" id="sales-tab" style="display: block;">
                <div class="chart-container">
                    <div class="chart">
                        <h3>Ticket Sales by Type</h3>
                        <canvas id="ticketTypeChart"></canvas>
                    </div>
                    
                    <div class="chart">
                        <h3>Revenue Breakdown</h3>
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
                
                <div class="data-table">
                    <h3>Ticket Sales Details</h3>
                    <table id="ticketSalesTable">
                        <thead>
                            <tr>
                                <th>Ticket Type</th>
                                <th>Quantity Sold</th>
                                <th>Price Per Ticket</th>
                                <th>Total Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($ticket_stats as $stat): ?>
                                <tr>
                                    <td><?php echo ucfirst($stat['ticket_type']); ?></td>
                                    <td><?php echo $stat['count']; ?></td>
                                    <td>$<?php echo number_format($stat['total_revenue'] / $stat['count'], 2); ?></td>
                                    <td>$<?php echo number_format($stat['total_revenue'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (count($ticket_stats) === 0): ?>
                                <tr>
                                    <td colspan="4">No ticket sales data available.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <div class="tab-content" id="attendees-tab" style="display: none;">
                <div class="chart-container">
                    <div class="chart">
                        <h3>Check-in Distribution</h3>
                        <canvas id="checkinChart"></canvas>
                    </div>
                    
                    <div class="chart">
                        <h3>Check-in Status</h3>
                        <canvas id="checkinStatusChart"></canvas>
                    </div>
                </div>
                
                <div class="data-export">
                    <h3>Export Attendee Data</h3>
                    <p>Download the complete attendee list for this event.</p>
                    <a href="export_attendees.php?event_id=<?php echo $event_id; ?>" class="button">Export to CSV</a>
                </div>
            </div>
            
            <div class="tab-content" id="feedback-tab" style="display: none;">
                <div class="chart-container">
                    <div class="chart">
                        <h3>Feedback Rating Distribution</h3>
                        <canvas id="feedbackChart"></canvas>
                    </div>
                </div>
                
                <div class="data-table">
                    <h3>Feedback Comments</h3>
                    <table id="feedbackTable">
                        <thead>
                            <tr>
                                <th>Attendee</th>
                                <th>Rating</th>
                                <th>Comments</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Get feedback details
                            $stmt = $conn->prepare("
                                SELECT f.*, u.username
                                FROM feedback f
                                JOIN users u ON f.user_id = u.user_id
                                WHERE f.event_id = ?
                                ORDER BY f.submission_date DESC
                            ");
                            $stmt->bind_param("i", $event_id);
                            $stmt->execute();
                            $feedback_details = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
                            
                            foreach ($feedback_details as $feedback):
                            ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($feedback['username']); ?></td>
                                    <td class="rating">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <span class="star <?php echo $i <= $feedback['rating'] ? 'filled' : ''; ?>">★</span>
                                        <?php endfor; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($feedback['comments']); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($feedback['submission_date'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (count($feedback_details) === 0): ?>
                                <tr>
                                    <td colspan="4">No feedback data available.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <div class="button-container">
            <a href="download_report.php?event_id=<?php echo $event_id; ?>" class="button">Download Full Report</a>
            <a href="event_details.php?id=<?php echo $event_id; ?>" class="button button-secondary">Back to Event</a>
        </div>
    </main>

    <?php include '../includes/footer.php'; ?>
    <script src="../js/offline.js"></script>
    <script src="../js/analytics.js"></script>
    <script>
        // Sales chart
        const ticketTypeData = <?php echo json_encode(array_column($ticket_stats, 'ticket_type')); ?>;
        const ticketCountData = <?php echo json_encode(array_column($ticket_stats, 'count')); ?>;
        const ticketRevenueData = <?php echo json_encode(array_column($ticket_stats, 'total_revenue')); ?>;
        
        // Check-in data
        const checkinHours = <?php echo json_encode(array_column($checkin_distribution, 'hour')); ?>;
        const checkinCounts = <?php echo json_encode(array_column($checkin_distribution, 'count')); ?>;
        const checkedIn = <?php echo $checkin_stats['checked_in']; ?>;
        const notCheckedIn = <?php echo $checkin_stats['total_tickets'] - $checkin_stats['checked_in']; ?>;
        
        // Feedback data
        const feedbackRatings = <?php echo json_encode($ratings); ?>;
        
        document.addEventListener('DOMContentLoaded', function() {
            // Ticket type chart
            const ticketTypeCtx = document.getElementById('ticketTypeChart').getContext('2d');
            new Chart(ticketTypeCtx, {
                type: 'pie',
                data: {
                    labels: ticketTypeData.map(type => type.charAt(0).toUpperCase() + type.slice(1)),
                    datasets: [{
                        data: ticketCountData,
                        backgroundColor: [
                            'rgba(54, 162, 235, 0.7)',
                            'rgba(255, 206, 86, 0.7)',
                            'rgba(75, 192, 192, 0.7)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        }
                    }
                }
            });
            
            // Revenue chart
            const revenueCtx = document.getElementById('revenueChart').getContext('2d');
            new Chart(revenueCtx, {
                type: 'bar',
                data: {
                    labels: ticketTypeData.map(type => type.charAt(0).toUpperCase() + type.slice(1)),
                    datasets: [{
                        label: 'Revenue',
                        data: ticketRevenueData,
                        backgroundColor: 'rgba(54, 162, 235, 0.7)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return '$' + value;
                                }
                            }
                        }
                    }
                }
            });
            
            // Check-in chart
            const checkinCtx = document.getElementById('checkinChart').getContext('2d');
            new Chart(checkinCtx, {
                type: 'bar',
                data: {
                    labels: checkinHours.map(hour => {
                        const hourNum = parseInt(hour);
                        return hourNum > 12 ? (hourNum - 12) + ' PM' : (hourNum === 0 ? '12 AM' : hourNum === 12 ? '12 PM' : hourNum + ' AM');
                    }),
                    datasets: [{
                        label: 'Check-ins',
                        data: checkinCounts,
                        backgroundColor: 'rgba(75, 192, 192, 0.7)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
            
            // Check-in status chart
            const checkinStatusCtx = document.getElementById('checkinStatusChart').getContext('2d');
            new Chart(checkinStatusCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Checked In', 'Not Checked In'],
                    datasets: [{
                        data: [checkedIn, notCheckedIn],
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.7)',
                            'rgba(255, 99, 132, 0.7)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true
                }
            });
            
            // Feedback chart
            const feedbackCtx = document.getElementById('feedbackChart').getContext('2d');
            new Chart(feedbackCtx, {
                type: 'bar',
                data: {
                    labels: ['1 Star', '2 Stars', '3 Stars', '4 Stars', '5 Stars'],
                    datasets: [{
                        label: 'Number of Ratings',
                        data: feedbackRatings,
                        backgroundColor: 'rgba(255, 159, 64, 0.7)',
                        borderColor: 'rgba(255, 159, 64, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    }
                }
            });
            
            // Tab switching
            document.querySelectorAll('.analytics-tab').forEach(tab => {
                tab.addEventListener('click', function() {
                    // Remove active class from all tabs
                    document.querySelectorAll('.analytics-tab').forEach(t => 
                        t.classList.remove('active'));
                    
                    // Add active class to clicked tab
                    this.classList.add('active');
                    
                    // Hide all content sections
                    document.querySelectorAll('.tab-content').forEach(content => 
                        content.style.display = 'none');
                    
                    // Show selected content section
                    const targetId = this.getAttribute('data-target');
                    document.getElementById(targetId).style.display = 'block';
                });
            });
        });
    </script>
</body>
</html>